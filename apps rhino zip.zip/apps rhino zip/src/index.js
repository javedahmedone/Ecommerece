import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import { BrowserRouter, Router } from 'react-router-dom';
import history from './components/history'
ReactDOM.render(

  <BrowserRouter>
    <Router history={history}>
    <App />
    </Router>
  </BrowserRouter>
  , document.getElementById('root')
);

