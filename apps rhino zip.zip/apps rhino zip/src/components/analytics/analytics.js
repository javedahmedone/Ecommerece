import React from 'react';
import { useParams } from 'react-router-dom';
import { Link } from "react-router-dom";
import AnalyticsDelivery from './analyticsDelivery/analyticsDelivery';
import AnalyticsPayment from './analyticsPayment/analyticsPayment'
import AnalyticsCustom from './analyticsCustom/analyticsCustom';

export default function Analytics() {
  const { type } = useParams();

  return (
    <div className="product-body">
      <div className="container-fluid">
        <div className="content-div">
          <div className="row">
            <div className="col-1 col-md-auto">Analytics</div>
            <div className="col-1 col-md-auto ml-auto">
              <span className="material-icons" style={{cursor:"pointer"}}>
                expand_more
              </span>
            </div>
            <div className="col-1 col-md-auto">
              <span className="material-icons" style={{cursor:"pointer"}}>
                search
              </span>
            </div>
            <div class="col-1 col-md-auto ">                
                <span className="material-icons"  data-toggle="dropdown" style={{ cursor: "pointer" }}>
                  filter_alt
                </span>           
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                  <a class="dropdown-item" href="#">Action</a>
                  <a class="dropdown-item" href="#">Another action</a>
                  <a class="dropdown-item" href="#">Something else here</a>
                </div>
              </div>
              <div className="col-1 col-md-auto">
                <span className="material-icons" data-toggle="dropdown" style={{ cursor: "pointer" }}>
                  more_vert
                </span>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                  <a class="dropdown-item" href="#">More Actions</a>
                </div>
              </div>
          </div>
        </div>
        <div className="content-bottom">
          <div className="row">
            <Link to="/analytics/delivery" style={{ textDecoration: 'none', color: "#616161" }}><div className="col-6 col-md-auto">Deliveries</div></Link>
            <Link to="/analytics/payment" style={{ textDecoration: 'none', color: "#616161" }}><div className="col-6 col-md-auto">Payment</div></Link>
            <Link to="/analytics/custom" style={{ textDecoration: 'none', color: "#616161" }}><div className="col-6 col-md-auto">Custom</div></Link>
          </div>
        </div>

        <div>
          {type === 'payment' && <AnalyticsPayment />}
          {type === 'delivery' && <AnalyticsDelivery />}
          {type === 'custom' && <AnalyticsCustom />}
        </div>
      </div>
    </div>
  )
}
