import React, { Component } from 'react';
import CheckboxAll from '../../checkboxAll';

export default class AnalyticsDelivery extends Component {
  constructor(props) {
    super(props)
    this.state = {
      user: [
        {
          id:"1",
          order: "2021",
          name: "Vance Legros",
          location: "Port Keanu",
          status: "Pending"
        },
        { id:"2",
          order: "2021",
          name: "Kacey Kohler",
          location: "Port Asha",
          status: "Success"
        },
        { id:"3",
          order: "2021",
          name: "Cloyd Russel",
          location: "Port Ella",
          status: "Pending"
        },
        { id:"4",
          order: "2021",
          name: "Vance Legros",
          location: "Port Keanu",
          status: "Delivered"
        },
        { id:"5",
          order: "2021",
          name: "Kacey Kohler",
          location: "Port Asha",
          status: "Pending"
        },
        { id:"6",
          order: "2021",
          name: "Cloyd Russel",
          location: "Port Ella",
          status: "Failed"
        },
        { id:"7",
          order: "2021",
          name: "Kacey Kohler",
          location: "Port Asha",
          status: "Failed"
        },
        { id:"8",
          order: "2021",
          name: "Cloyd Russel",
          location: "Port Ella",
          status: "Pending"
        },
        { id:"9",
          order: "2021",
          name: "Kacey Kohler",
          location: "Port Asha",
          status: "Success"
        },
        { id:"10",
          order: "2021",
          name: "Cloyd Russel",
          location: "Port Ella",
          status: "Pending"
        },
        { id:"11",
          order: "2021",
          name: "Kacey Kohler",
          location: "Port Asha",
          status: "Delivered"
        },
        { id:"12",
          order: "2021",
          name: "Cloyd Russel",
          location: "Port Ella",
          status: "Failed"
        },
        { id:"13",
          order: "2021",
          name: "Kacey Kohler",
          location: "Port Asha",
          status: "Success"
        },
        { id:"14",
          order: "2021",
          name: "Cloyd Russel",
          location: "Port Ella",
          status: "Pending"
        },
        { id:"15",
          order: "2021",
          name: "Kacey Kohler",
          location: "Port Asha",
          status: "Pending"
        },
        { id:"16",
          order: "2021",
          name: "Cloyd Russel",
          location: "Port Ella",
          status: "Failed"
        },
        { id:"18",
          order: "2021",
          name: "Kacey Kohler",
          location: "Port Asha",
          status: "Pending"
        },
        { id:"19",
          order: "2021",
          name: "Cloyd Russel",
          location: "Port Ella",
          status: "Success"
        },
      ],
      userDetails:{},
    }
  }
  tableClick(item){
   this.setState({
     userDetails:item
   })
  }
  
  handleAllChecked = event => {
    let user = this.state.user;
    user.forEach(users => (users.isChecked = event.target.checked));
    this.setState({ user: user });
  };
  
  handleCheckChieldElement = (event) => {
    let user = this.state.user;
    user.forEach((users) => {
      if (users.id === event.target.value)
        users.isChecked = event.target.checked;
    });
    this.setState({ user: user });
  };

  render() {
    return (
      <div className="row product-main-row" >
        <div className="table-responsive col-md-8 product-table">
          <table className="col-md-12 table" >
            <thead style={{ background: "linear-gradient(90deg, #ACCBEE 0%, #E7F0FD 100%) " }}>
              <tr className="tr-head">
                <th scope="col">
                <input type="checkbox" onClick={this.handleAllChecked} style={{cursor:"pointer"}} />
                </th>
                <th scope="col">Order ID</th>
                <th scope="col">Customer Name</th>
                <th scope="col">Store</th>
                <th scope="col">Rider</th>
                <th scope="col">Status</th>
              </tr>
            </thead>
            <tbody style={{ background: "#FFFFFF" }}>

              {this.state.user.map((user) => (
                <tr className="row-data"  onClick={()=>{this.tableClick(user)}} style={{cursor:"pointer"}}>
                  <td>
                  <CheckboxAll
                          handleCheckChieldElement={this.handleCheckChieldElement}
                          {...user}
                        />
                  </td>
                  <td>{user.order}</td>
                  <td>{user.name}</td>
                  <td>{user.location}</td>
                  <td>{user.name}</td>
                  <td>{user.status}</td>
                </tr>
              ))}
            </tbody>
          </table>

        </div>
        <div className="col-md-4 product-card" style={{ height: "720px", marginTop: "20px" }}>
          <div className="product-top-div">
            <div className="row">
              <div className="col-auto col-md-auto">Delivery Details</div>
            
            </div>
          </div>
          <div className="product-body-div">

            <div className="mt-3" style={{ fontWeight: "700" }}>Customer Details</div>

            <div className="row mt-2">
              <div className="col-auto" style={{ fontWeight: "700" }}>Name:</div>
              <div className="col-auto">{this.state.userDetails.name}</div>
            </div>
            <div className="row mt-2">
              <div className="col-auto" style={{ fontWeight: "700" }}>M:</div>
              <div className="col-auto">+91 9976542356</div>
            </div>

            <div className="mt-3" style={{ fontWeight: "700" }}>Store Details</div>

            <div className="row mt-2">
              <div className="col-auto" style={{ fontWeight: "700" }}>Name:</div>
              <div className="col-auto">{this.state.userDetails.name}</div>
            </div>
            <div className="row mt-2">
              <div className="col-auto" style={{ fontWeight: "700" }}>M:</div>
              <div className="col-auto">+91 9976542356</div>
            </div>

            <div className="mt-3" style={{ fontWeight: "700" }}>Delivery Person Details</div>

            <div className="row mt-2">
              <div className="col-auto" style={{ fontWeight: "700" }}>Name:</div>
              <div className="col-auto">{this.state.userDetails.name}</div>
            </div>
            <div className="row mt-2">
              <div className="col-auto" style={{ fontWeight: "700" }}>M:</div>
              <div className="col-auto">+91 9976542356</div>
            </div>

            <div className="row mt-2">
              <div className="col-auto" style={{ fontWeight: "700" }}>Order Details</div>
            </div>
            <div className="row mt-2">
              <div className="col-auto col-md-9">1. Baccardi White Rum (750 ML)</div>
              <div className="col-auto col-md-3" style={{ textAlign: "right" }}>$ 95 </div>
            </div>
            <div className="row mt-2">
              <div className="col-auto col-md-9">2. LIT- Gin, Vodka, Rum (500 ML) </div>
              <div className="col-auto col-md-3" style={{ textAlign: "right" }}>$ 60</div>
            </div>
            <hr />
            <div className="row mt-2">
              <div className="col-auto col-md-9">Delivery Tip</div>
              <div className="col-auto col-md-3" style={{ textAlign: "right" }}>$ 250 </div>
            </div>
            <div className="row mt-2">
              <div className="col-auto col-md-9">Delivery Fee</div>
              <div className="col-auto col-md-3" style={{ textAlign: "right" }}>$ 10</div>
            </div>
            <div className="row mt-2">
              <div className="col-auto col-md-9">Payment Gateway Charges</div>
              <div className="col-auto col-md-3" style={{ textAlign: "right" }}>$ 5.58</div>
            </div>
            <div className="row mt-2">
              <div className="col-auto col-md-9">Taxes</div>
              <div className="col-auto col-md-3" style={{ textAlign: "right" }}>$ 30</div>
            </div>
            <div className="row mt-2">
              <div className="col-auto col-md-9">Admin Commission</div>
              <div className="col-auto col-md-3" style={{ textAlign: "right" }}>$ 15</div>
            </div>
            <hr />
            <div className="row mt-2">
              <div className="col-auto col-md-9">Total</div>
              <div className="col-auto col-md-3" style={{ textAlign: "right" }}>$ 235.58</div>
            </div>

            <div className="row mt-3">
              <div className="col-auto col-md-6 offset-6" style={{ textAlign: "right", fontSize: "12px" }}>Delivery Time: 25 Min</div>
            </div>

          </div>
        </div>
      </div>
    )
  }
}

