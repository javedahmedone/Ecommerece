import React, { Component } from 'react';
import { LineChart,ComposedChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, PieChart, Bar, Pie, Cell, ResponsiveContainer } from 'recharts';
import './analyticsPayment.scss'
import DeleteAlert from '../../deleteAlert'
import CheckboxAll from '../../checkboxAll';

export default class AnalyticsPayment extends Component {
  constructor(props) {
    super(props)
    this.state = {
      user: [
        { id:"1",
          transaction: "Marsala",
          paidBy: "Barley",
          paidTo: "Food",
          status: "Out of stock"
        },
        { id:"2",
          transaction: "Marsala",
          paidBy: "Barley",
          paidTo: "Food",
          status: "Out of stock"
        },
        { id:"3",
          transaction: "Marsala",
          paidBy: "Barley",
          paidTo: "Food",
          status: "Out of stock"
        },
        { id:"4",
          transaction: "Marsala",
          paidBy: "Barley",
          paidTo: "Food",
          status: "Out of stock"
        },
        { id:"5",
          transaction: "Marsala",
          paidBy: "Barley",
          paidTo: "Food",
          status: "Out of stock"
        },
        { id:"6",
          transaction: "Marsala",
          paidBy: "Barley",
          paidTo: "Food",
          status: "Out of stock"
        },
        { id:"7",
          transaction: "Marsala",
          paidBy: "Barley",
          paidTo: "Food",
          status: "Out of stock"
        },
        { id:"8",
          transaction: "Marsala",
          paidBy: "Barley",
          paidTo: "Food",
          status: "Out of stock"
        },
        { id:"9",
          transaction: "Marsala",
          paidBy: "Barley",
          paidTo: "Food",
          status: "Out of stock"
        },
        { id:"10",
          transaction: "Marsala",
          paidBy: "Barley",
          paidTo: "Food",
          status: "Out of stock"
        },
        { id:"11",
          transaction: "Marsala",
          paidBy: "Barley",
          paidTo: "Food",
          status: "Out of stock"
        },
        { id:"12",
          transaction: "Marsala",
          paidBy: "Barley",
          paidTo: "Food",
          status: "Out of stock"
        },
        { id:"13",
          transaction: "Marsala",
          paidBy: "Barley",
          paidTo: "Food",
          status: "Out of stock"
        },
        { id:"14",
          transaction: "Marsala",
          paidBy: "Barley",
          paidTo: "Food",
          status: "Out of stock"
        },
        { id:"15",
          transaction: "Marsala",
          paidBy: "Barley",
          paidTo: "Food",
          status: "Out of stock"
        },
        { id:"16",
          transaction: "Marsala",
          paidBy: "Barley",
          paidTo: "Food",
          status: "Out of stock"
        },
        { id:"17",
          transaction: "Marsala",
          paidBy: "Barley",
          paidTo: "Food",
          status: "Out of stock"
        },
        { id:"18",
          transaction: "Marsala",
          paidBy: "Barley",
          paidTo: "Food",
          status: "Out of stock"
        },
      ],
      userDetails:{},
      openDelete:false,
      showHideToggle:true,
    }
  }
    
  toggle = () => {
    this.setState({
      showHideToggle: !this.state.showHideToggle
    });
  }
  tableClick(item){
   this.setState({
     userDetails:item
   })
  }
  delete(e){
    this.setState({
      openDelete:true
    })
  }
  
  handleClose = () => {
    this.setState({
      openDelete: false
    })
  }
  
  handleAllChecked = event => {
    let user = this.state.user;
    user.forEach(users => (users.isChecked = event.target.checked));
    this.setState({ user: user });
  };
  
  handleCheckChieldElement = (event) => {
    let user = this.state.user;
    user.forEach((users) => {
      if (users.id === event.target.value)
        users.isChecked = event.target.checked;
    });
    this.setState({ user: user });
  };
  render() {

    const data = [
      {
        name: '',
        uv: 10,
        pv: 10,
        amt: 2400,
      },
      {
        name: '',
        uv: 22,
        pv: 30,
        amt: 2210,
      },
      {
        name: '',
        uv: 29,
        pv: 20,
        amt: 2290,
      },
      {
        name: '',
        uv: 22,
        pv: 20,
        amt: 2000,
      },
      {
        name: '',
        uv: 17,
        pv: 40,
        amt: 2181,
      },
      {
        name: '',
        uv: 29,
        pv: 30,
        amt: 2500,
      },
      {
        name: '',
        uv: 25,
        pv: 20,
        amt: 2100,
      },
      {
        name: '',
        uv: 45,
        pv: 60,
        amt: 2100,
      },
      {
        name: '',
        uv: 25,
        pv: 20,
        amt: 2100,
      },
      {
        name: '',
        uv: 25,
        pv: 20,
        amt: 2100,
      },
      {
        name: '',
        uv: 23,
        pv: 40,
        amt: 2100,
      },
      {
        name: '',
        uv: 40,
        pv: 60,
        amt: 2100,
      },
      {
        name: '',
        uv: 45,
        pv: 40,
        amt: 2100,
      },
      {
        name: '',
        uv: 45,
        pv: 60,
        amt: 2100,
      },
    ];

    const pieData = [
      { name: 'Store', value: 400 },
      { name: 'Person', value: 300 },
      { name: 'Super Admin', value: 300 },
      { name: 'Others', value: 200 },
    ];
    const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];
    let name = function (label) {
      return label.name;
    }
    return (
      <div className="payment-body">
        <div className="container-fluid">
          <div className="top">
            <div className="row">

              <div className="col-6 col-md-3 mt-2 top-content">
                <div className="row">
                  <div className="col-md-12">
                    Successful Payments
                 </div>
                  <div className="col-md-12 pt-2 top-price">
                    246K
                 </div>
                  <div className="col-md-12 pt-2 top-percentage">
                    <span className="material-icons" style={{ fontSize: "12px" }}>
                      arrow_upward
                  </span>
                  13.4%
                 </div>
                </div>
              </div>

              <div className="col-6 col-md-3 mt-2 top-content">
                <div className="row">
                  <div className="col-md-12">
                    Failed Payments
                 </div>
                  <div className="col-md-12 pt-2 top-price">
                    246K
                 </div>
                  <div className="col-md-12 pt-2 top-percentage" style={{ color: "rgb(255,106,106)" }}>
                    <span className="material-icons" style={{ fontSize: "12px" }}>
                      south
                  </span>
                  13.4%
                 </div>
                </div>
              </div>

              <div className="col-6 col-sm-6 col-md-3 mt-2 top-content">
                <div className="row">
                  <div className="col-md-12">
                    Average Payment Size
                 </div>
                  <div className="col-md-12 pt-2 top-price">
                    50 USD
                 </div>
                  <div className="col-md-12 pt-2 top-percentage">
                    <span className="material-icons" style={{ fontSize: "12px" }}>
                      arrow_upward
                  </span>
                  13.4%
                 </div>
                </div>
              </div>

              <div className="col-6 col-sm-6 col-md-3 mt-2 top-content">
                <div className="row">
                  <div className="col-md-12">
                    Total Refunds
                 </div>
                  <div className="col-md-12 pt-2 top-price">
                    5K
                 </div>
                  <div className="col-md-12 pt-2 top-percentage" style={{ color: "rgb(255,106,106)" }}>
                    <span className="material-icons" style={{ fontSize: "12px" }}>
                      south
                  </span>
                  13.4%
                 </div>
                </div>
              </div>

            </div>

          </div>
          <div className="graphs">
            <div className="row">
              <div className="col-12 col-md-8 line-graph">
                <ResponsiveContainer width="99%"  height={300}>
                <ComposedChart
                  data={data}
                  margin={{
                    top: 5,
                    right: 30,
                    left: 20,
                    bottom: 5,
                  }}
                >
                  <CartesianGrid stroke="#f5f5f5"  />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="pv" stroke="#8884d8" />
                  <Bar dataKey="uv" barSize={3} fill="#8d77a1" />
                  </ComposedChart>
                </ResponsiveContainer>

              </div>

              <div className="col-12 col-md-4 pie-graph">
                <PieChart
                  width={400}
                  height={400}
                  margin={{
                    top: 0,
                    right: 15,
                    left: 40,
                    bottom: 5,
                  }}
                  onMouseEnter={this.onPieEnter}>
                  <Pie data={pieData}
                    cx={120}
                    cy={200}
                    innerRadius={60}
                    outerRadius={80}
                    fill="#8884d8"
                    paddingAngle={5}
                    dataKey="value" label={name}
                  >
                    {data.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                </PieChart>
              </div>
            </div>
          </div>

          <div className="row product-main-row" >
            <div className="table-responsive col-md-8 product-table">
              <table className="col-md-12 table" >
                <thead style={{ background: "linear-gradient(90deg, #ACCBEE 0%, #E7F0FD 100%) " }}>
                  <tr className="tr-head">
                    <th scope="col">
                    <input type="checkbox" onClick={this.handleAllChecked} style={{cursor:"pointer"}} />
                    </th>
                    <th scope="col">Transaction ID</th>
                    <th scope="col">Paid By</th>
                    <th scope="col">Paid To</th>
                    <th scope="col">Status</th>
                  </tr>
                </thead>
                <tbody style={{ background: "#FFFFFF" }}>

                  {this.state.user.map((user) => (
                    <tr className="row-data"  onClick={()=>{this.tableClick(user)}} style={{cursor:"pointer"}}>
                      <td>
                      <CheckboxAll
                          handleCheckChieldElement={this.handleCheckChieldElement}
                          {...user}
                        />
                      </td>
                      <td>{user.transaction}</td>
                      <td>{user.paidBy}</td>
                      <td>{user.paidTo}</td>
                      <td>{user.status}</td>
                    </tr>
                  ))}
                </tbody>
              </table>

            </div>
            <div className="col-md-4 product-card payment-card1">
              <div className="product-top-div">
                <div className="row">
                  <div className="col-auto col-md-auto">Product Details</div>
                  <div className="col-1 col-md-auto ml-auto">
                      {this.state.showHideToggle &&                 
                        <div >
                          <span className="material-icons" style={{ cursor: "pointer" }} onClick={this.toggle}>
                            toggle_on
                          </span>
                        </div> 
                      }
                      {!this.state.showHideToggle &&                 
                        <div>
                          <span className="material-icons" style={{ cursor: "pointer" }} onClick={this.toggle}>
                            toggle_off
                          </span>
                        </div> 
                      }
                    </div>  
                  <div className="col-1 col-md-auto">
                    <span className="material-icons">
                      edit_note
                    </span>
                  </div>
                  <div className="col-1 col-md-auto">
                    <span className="material-icons" onClick={this.delete.bind(this)} style={{cursor:"pointer"}}>
                      delete
                    </span>
                    <DeleteAlert open={this.state.openDelete} close={this.handleClose} />
                  </div>
                </div>
              </div>
              <div className="product-body-div">
                <div className="text-center">
                  <img src="wine.jpg" style={{ height: "175px", width: "175px", padding: "10px" }} alt="..." />

                </div>
                <div className="mt-3 text-center" style={{ fontWeight: "700" }}>Table Wine</div>
                <div className="mt-4 text-justify">
                  Table wine is a wine term with two different meanings: a style of wine and a quality level within wine classification. In the United States, table wine primarily designates a wine style: ordinary wine which is neither fortified nor sparkling nor expensive.
                </div>
                <div className="row mt-4">
                  <div className="col-auto" style={{ fontWeight: "700" }}>Variant</div>
                  <div className="col-auto ml-auto" style={{ fontSize: "12px", color: "#005FFF" }}>Add new variants</div>
                </div>
                <div className="row mt-2">
                  <div className="col-auto">1</div>
                  <div className="col-auto ml-auto">250 ML</div>
                  <div className="col-auto ml-auto">$500</div>
                  <div className="col-auto ml-auto">10% off</div>
                  <div className="col-auto ml-auto">
                    <span class="material-icons" style={{ color: '#C70000' }}>
                      close
                    </span>
                  </div>
                </div>
                <div className="row mt-2">
                  <div className="col-auto">2</div>
                  <div className="col-auto ml-auto">250 ML</div>
                  <div className="col-auto ml-auto">$500</div>
                  <div className="col-auto ml-auto">10% off</div>
                  <div className="col-auto ml-auto">
                    <span class="material-icons" style={{ color: '#C70000' }}>
                      close
                    </span>
                  </div>
                </div>
                <div className="row mt-2">
                  <div className="col-auto">3</div>
                  <div className="col-auto ml-auto">250 ML</div>
                  <div className="col-auto ml-auto">$500</div>
                  <div className="col-auto ml-auto">10% off</div>
                  <div className="col-auto ml-auto">
                    <span class="material-icons" style={{ color: '#C70000' }}>
                      close
                    </span>
                  </div>
                </div>
                <div className="row mt-4">
                  <div className="col-auto" style={{ fontWeight: "700" }}>Locations</div>
                  <div className="col-auto ml-auto" style={{ fontSize: "12px", color: "#005FFF" }}>Add new location</div>
                </div>
                <div className="row mt-2">
                  <div className="col-auto">1</div>
                  <div className="col-auto">Chennai,India</div>
                  <div className="col-auto ml-auto">
                    <span class="material-icons" style={{ color: '#C70000' }}>
                      close
                    </span>
                  </div>
                </div>
                <div className="row mt-2">
                  <div className="col-auto">2</div>
                  <div className="col-auto">Delhi,India </div>
                  <div className="col-auto ml-auto">
                    <span class="material-icons" style={{ color: '#C70000' }}>
                      close
                    </span>
                  </div>
                </div>
                <div className="row mt-2">
                  <div className="col-auto">3</div>
                  <div className="col-auto">Mohali, Punjab, India </div>
                  <div className="col-auto ml-auto">
                    <span class="material-icons" style={{ color: '#C70000' }}>
                      close
                    </span>
                  </div>
                </div>


              </div>
            </div>
          </div>


        </div>
      </div>
    )
  }
}
