import React, { Component } from 'react';
import './analyticsCustom.scss'

export default class AnalyticsCustom extends Component {
  constructor(props) {
    super(props)
    this.state = {

      userDetails: {},
      openDelete: false,
    }
  }

  delete(e) {
    this.setState({
      openDelete: true
    })
  }

  handleClose = () => {
    this.setState({
      openDelete: false
    })
  }

  render() {
    return (
      <div className="custom-body">
        <div className="container-fluid">
          <div className="row">
            <div className="col-12 col-md-8">
              <div className="row">
                <div className="col-12 col-md-12 mt-2 custom-heading">
                  <b>Generate New Report</b>
                </div>

                <div className="col-12 col-md-12 custom-content">
                  <div className="row">
                    <div className="col-6 col-md-6 mt-4 pt-4">
                    <input type="date" id="" className="form-control date" placeholder="12/07/2020 - 11/08/2020" />
                    </div>
                    <div className="col-6 col-md-6 mt-4 pt-4">
                    <input type="time" id="" className="form-control time" placeholder="12/07/2020 - 11/08/2020" />
                    </div>
                    <div className="col-6 col-md-6 mt-4 pt-4">
                    <select id="" className="dropdown customer-name">
                      <option value="48">Customer Name</option>
                      <option value="60">Test Test Test Test Test</option>
                      <option value="68">Assets</option>
                      <option value="262">WebServices Test test test test test tes</option>
                      <option value="451">Test Icon 1</option>
                      <option value="2319">Test New Icon</option>
                      <option value="2378">English language</option>
                      <option value="5073">CAR</option>
                      <option value="5323">Testing123</option>
                      <option value="6837">Test New Icon1</option>
                      </select>                   
                    </div>

                      <div className="col-6 col-md-6 mt-4 pt-4">
                    <select id="" className="dropdown customer-name">
                      <option value="48">Store Name</option>
                      <option value="60">Test Test Test Test Test</option>
                      <option value="68">Assets</option>
                      <option value="262">WebServices Test test test test test tes</option>
                      <option value="451">Test Icon 1</option>
                      <option value="2319">Test New Icon</option>
                      <option value="2378">English language</option>
                      <option value="5073">CAR</option>
                      <option value="5323">Testing123</option>
                      <option value="6837">Test New Icon1</option>
                      </select>                   
                    </div>
                    
                    <div className="col-6 col-md-6 mt-4 pt-4">
                    <select id="" className="dropdown customer-name">
                      <option value="48">Location</option>
                      <option value="60">Test Test Test Test Test</option>
                      <option value="68">Assets</option>
                      <option value="262">WebServices Test test test test test tes</option>
                      <option value="451">Test Icon 1</option>
                      <option value="2319">Test New Icon</option>
                      <option value="2378">English language</option>
                      <option value="5073">CAR</option>
                      <option value="5323">Testing123</option>
                      <option value="6837">Test New Icon1</option>
                      </select>                   
                    </div>

                   <div className="col-6 col-md-6 mt-4 pt-4">
                    <select id="" className="dropdown customer-name">
                      <option value="48">Status</option>
                      <option value="60">Test Test Test Test Test</option>
                      <option value="68">Assets</option>
                      <option value="262">WebServices Test test test test test tes</option>
                      <option value="451">Test Icon 1</option>
                      <option value="2319">Test New Icon</option>
                      <option value="2378">English language</option>
                      <option value="5073">CAR</option>
                      <option value="5323">Testing123</option>
                      <option value="6837">Test New Icon1</option>
                      </select>                   
                    </div>

                    <div className="col-6 col-md-6 mt-4 pt-4">
                      <div className="row">

                      <div className="col-5 col-md-5">
                      <select id="" className="dropdown customer-details">
                      <option value="48">Min. Order Items</option>
                      <option value="60">Test Test Test Test Test</option>
                      <option value="68">Assets</option>
                      <option value="262">WebServices Test test test test test tes</option>
                      <option value="451">Test Icon 1</option>
                      <option value="2319">Test New Icon</option>
                      <option value="2378">English language</option>
                      <option value="5073">CAR</option>
                      <option value="5323">Testing123</option>
                      <option value="6837">Test New Icon1</option>
                      </select>                   
                      </div>

                      <div className="col-5 col-md-5">
                      <select id="" className="dropdown customer-details">
                      <option value="48">Max Order Items</option>
                      <option value="60">Test Test Test Test Test</option>
                      <option value="68">Assets</option>
                      <option value="262">WebServices Test test test test test tes</option>
                      <option value="451">Test Icon 1</option>
                      <option value="2319">Test New Icon</option>
                      <option value="2378">English language</option>
                      <option value="5073">CAR</option>
                      <option value="5323">Testing123</option>
                      <option value="6837">Test New Icon1</option>
                      </select>                   
                      </div>

                      </div>
                    </div>
                  
                    <div className="col-6 col-md-6 mt-4 pt-4">
                      <div className="row">

                      <div className="col-5 col-md-5">
                      <select id="" className="dropdown customer-details">
                      <option value="48">Min. SKUs</option>
                      <option value="60">Test Test Test Test Test</option>
                      <option value="68">Assets</option>
                      <option value="262">WebServices Test test test test test tes</option>
                      <option value="451">Test Icon 1</option>
                      <option value="2319">Test New Icon</option>
                      <option value="2378">English language</option>
                      <option value="5073">CAR</option>
                      <option value="5323">Testing123</option>
                      <option value="6837">Test New Icon1</option>
                      </select>                   
                      </div>

                      <div className="col-5 col-md-5">
                      <select id="" className="dropdown customer-details">
                      <option value="48">Max SKUs</option>
                      <option value="60">Test Test Test Test Test</option>
                      <option value="68">Assets</option>
                      <option value="262">WebServices Test test test test test tes</option>
                      <option value="451">Test Icon 1</option>
                      <option value="2319">Test New Icon</option>
                      <option value="2378">English language</option>
                      <option value="5073">CAR</option>
                      <option value="5323">Testing123</option>
                      <option value="6837">Test New Icon1</option>
                      </select>                   
                      </div>

                      </div>
                    </div>
                 
                    <div className="col-6 col-md-6 mt-4 pt-4">
                      <div className="row">

                      <div className="col-5 col-md-5">
                      <select id="" className="dropdown customer-details">
                      <option value="48">Min. Order Amount</option>
                      <option value="60">Test Test Test Test Test</option>
                      <option value="68">Assets</option>
                      <option value="262">WebServices Test test test test test tes</option>
                      <option value="451">Test Icon 1</option>
                      <option value="2319">Test New Icon</option>
                      <option value="2378">English language</option>
                      <option value="5073">CAR</option>
                      <option value="5323">Testing123</option>
                      <option value="6837">Test New Icon1</option>
                      </select>                   
                      </div>

                      <div className="col-5 col-md-5">
                      <select id="" className="dropdown customer-details">
                      <option value="48">Max. Order Amount</option>
                      <option value="60">Test Test Test Test Test</option>
                      <option value="68">Assets</option>
                      <option value="262">WebServices Test test test test test tes</option>
                      <option value="451">Test Icon 1</option>
                      <option value="2319">Test New Icon</option>
                      <option value="2378">English language</option>
                      <option value="5073">CAR</option>
                      <option value="5323">Testing123</option>
                      <option value="6837">Test New Icon1</option>
                      </select>                   
                      </div>

                      </div>
                    </div>
                 
                    <div className="col-6 col-md-6 mt-4 pt-4">
                      <div className="row">

                      <div className="col-5 col-md-5">
                      <select id="" className="dropdown customer-details">
                      <option value="48">Min. Tip</option>
                      <option value="60">Test Test Test Test Test</option>
                      <option value="68">Assets</option>
                      <option value="262">WebServices Test test test test test tes</option>
                      <option value="451">Test Icon 1</option>
                      <option value="2319">Test New Icon</option>
                      <option value="2378">English language</option>
                      <option value="5073">CAR</option>
                      <option value="5323">Testing123</option>
                      <option value="6837">Test New Icon1</option>
                      </select>                   
                      </div>

                      <div className="col-5 col-md-5">
                      <select id="" className="dropdown customer-details">
                      <option value="48">Max Tip</option>
                      <option value="60">Test Test Test Test Test</option>
                      <option value="68">Assets</option>
                      <option value="262">WebServices Test test test test test tes</option>
                      <option value="451">Test Icon 1</option>
                      <option value="2319">Test New Icon</option>
                      <option value="2378">English language</option>
                      <option value="5073">CAR</option>
                      <option value="5323">Testing123</option>
                      <option value="6837">Test New Icon1</option>
                      </select>                   
                      </div>

                      </div>
                    </div>
                 
                    <div className="col-6 col-md-6 mt-4 pt-4">
                      <div className="row">

                      <div className="col-5 col-md-5">
                      <select id="" className="dropdown customer-details">
                      <option value="48">Min. Delivery Time</option>
                      <option value="60">Test Test Test Test Test</option>
                      <option value="68">Assets</option>
                      <option value="262">WebServices Test test test test test tes</option>
                      <option value="451">Test Icon 1</option>
                      <option value="2319">Test New Icon</option>
                      <option value="2378">English language</option>
                      <option value="5073">CAR</option>
                      <option value="5323">Testing123</option>
                      <option value="6837">Test New Icon1</option>
                      </select>                   
                      </div>

                      <div className="col-5 col-md-5">
                      <select id="" className="dropdown customer-details">
                      <option value="48">Min. Delivery Time</option>
                      <option value="60">Test Test Test Test Test</option>
                      <option value="68">Assets</option>
                      <option value="262">WebServices Test test test test test tes</option>
                      <option value="451">Test Icon 1</option>
                      <option value="2319">Test New Icon</option>
                      <option value="2378">English language</option>
                      <option value="5073">CAR</option>
                      <option value="5323">Testing123</option>
                      <option value="6837">Test New Icon1</option>
                      </select>                   
                      </div>

                      </div>
                    </div>

                    <div className="col-12 col-md-12 mt-4 pt-4">
                      <div className="row">
                        <div className="col-2 col-md-auto ml-auto">
                          Cancel
                        </div>
                        <div className="col-4 col-md-auto">
                          <input type="submit" className="custom-button" value="Generate" />
                        </div>
                      </div>
                      </div>          
                  </div>
                </div>
              </div>
            </div>


            <div className='col-12 col-md-4 side-content-preference'>
              <div className='row'>
                <div className="col-12 col-md-12 mt-2">
                  <div className="row">
                    <div className="col-12 col-md-12 help-pre">
                      <div className="row">
                        <div className="col-12 col-md-auto">
                          <b>How to apply filters</b>
                        </div>
                      </div>
                    </div>
                    <div className="col-12 col-md-12 pre-content">
                      <div className="row">

                        <div className="col-md-12 ">
                          <div className="row">
                            <div className='col-3 col-md-3'>
                              <span className="large material-icons">
                                event
                                </span>

                            </div>
                            <div className='col-9 col-md-9'>
                              Select the date range (i.e Starting and Ending date).
                              You can not select more than 3 months range.
                              You can choose the time period of every day.
                            </div>
                          </div>
                        </div>

                        <div className="col-md-12 mt-2">
                          <div className="row">
                            <div className='col-3 col-md-3'>
                              <span className="large material-icons">
                                person
                                </span>

                            </div>
                            <div className='col-9 col-md-9'>
                              Customize the report for specific Customers, Stores and Delivery person by
                              selective on or more from the available dropdown.
                            </div>
                          </div>
                        </div>


                        <div className="col-md-12 mt-2">
                          <div className="row">
                            <div className='col-3 col-md-3'>
                              <span className="large material-icons">
                                assignment
                                </span>

                            </div>
                            <div className='col-9 col-md-9'>
                              Use all order details data such as No. of ordered Items,
                              total no. of ordered SKUs and by order amount range for any order.
                             </div>
                          </div>
                        </div>

                        <div className="col-md-12 mt-2 ">
                          <div className="row">
                            <div className='col-3 col-md-3'>
                              <span className="large material-icons">
                                location_on
                                </span>

                            </div>
                            <div className='col-9 col-md-9'>
                              Select the date range (i.e Starting and Ending date). Report will give include the data
                              for that range only. You can not select more than 3 months range.
                            </div>
                          </div>
                        </div>

                        <div className="col-md-12 mt-2">
                          <div className="row">
                            <div className='col-3 col-md-3'>
                              <span className="large material-icons">
                                av_timer
                                </span>

                            </div>
                            <div className='col-9 col-md-9'>
                              Select the date range (i.e Starting and Ending date). Report will
                              give include the data for that range only.
                              You can not select more than 3 months range.
                            </div>
                          </div>
                        </div>

                        <div className="col-md-12 mt-2">
                          <div className="row">
                            <div className='col-3 col-md-3'>
                              <span className="large material-icons">
                                attach_money
                                </span>

                            </div>
                            <div className='col-9 col-md-9'>
                              Select the date range (i.e Starting and Ending date).
                              Report will give include the data for that range only.
                              You can not select more than 3 months range.
                            </div>
                          </div>
                        </div>

                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>


          </div>
        </div>
      </div>

    )
  }
}
