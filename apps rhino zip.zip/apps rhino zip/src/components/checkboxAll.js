import React from "react";

export const CheckboxAll = (props) => {
  return (
      <input
        onClick={props.handleCheckChieldElement}
        type="checkbox"
        checked={props.isChecked}
        value={props.id}
        style={{cursor:"pointer"}}
      />
  );
};

export default CheckboxAll;