import React, { Component } from 'react';
import './boonzeBlue4.scss'
export default class BoonzeBlue4 extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div className='boonze-4'>
        <div className="container">
          <div className="row">
          <div className='col-12 col-md-12 div-boonze-4'>             
            </div>
            <div className='col-12 col-md-12 mt-4 pt-4 content-boonze-4'>
              <b>"Your limitation—it’s only your imagination."</b>
            </div>
            <div className='col-12 col-md-12 mt-4 content2-boonze-4'>
              <b>- Slightly unknown</b>
            </div>
            <div className='col-12 col-md-12 mt-4 pt-4 div-boonze2-4'>             
            </div>
          </div>
        </div>
      </div>
    )
  }
}
