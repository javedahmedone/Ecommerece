import React, { Component } from 'react';
import './boonzeBlue2.scss'
export default class BoonzeBlue2 extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div className='boonze-2'>
        <div className="container-fluid">
          <div className="row">
            <div className='col-12 col-md-12 image-2'>
              <div className='row'>
                <div className='col-5 col-md-5 offset-3 heading-2'>
                  <b>Who we are?</b>
                </div>
                <div className='col-5 col-md-5 offset-3 heading-3'>
                  <b>Eat. Drink. Repeat Boozebite</b>
                </div>
                <div className='col-5 col-md-5 offset-3 content-boonze-2'>
                <b>Lorem ipsum dolor sit amet, consetetur sadipscing elitr,
                 sed diam nonumy eirmod tempor invidunt ut labore et dolore magna 
                 aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo 
                 dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est 
                </b>
                </div>
                <div className='col-5 col-md-5 offset-3' style={{textAlign:"center"}}>
                <input type="submit" className="btn-boonze-2" value="Know more" />               
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}
