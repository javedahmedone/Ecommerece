import React, { Component } from 'react';
import './boonzeBlue1.scss'
export default class BoonzeBlue1 extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div className='boonze-1'>
        <div className="container-fluid">
          <div className="row">
            <div className="col-12 col-md-12 logo-div">
              <div className="w-100 d-flex">
                <img
                  src="relinns.png"
                  alt="relinns-logo"
                  className="logo-relinns d-flex justify-content-between"
                />
              </div>
            </div>
            <div className='col-12 col-md-12 image-thought'>
              <div className='row'>
              
                <div className='col-4 col-md-4 offset-1 pt-4 div-location'>
                  <div className='row'>
                    <div className='col-12 col-md-12 ml-2 heading-location'>
                    <b>Share Location | Explore | Order</b>
                    </div>
                    <div className='col-12 col-md-12 ml-2 mt-2'>
                      <input type='text' className='location-input' />                
                    </div>
                  </div>
                </div>
              </div>
            </div>
            {/* <div className='col-12 col-md-12 image-2'>

            </div> */}

          </div>
        </div>
      </div>
    )
  }
}
