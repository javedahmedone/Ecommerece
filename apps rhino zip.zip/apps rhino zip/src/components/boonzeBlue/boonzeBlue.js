import React, { Component } from 'react';
import BoonzeBlue1 from './boonzeBlue1/boonzeBlue1';
import BoonzeBlue2 from './boonzeBlue2/boonzeBlue2';
import BoonzeBlue3 from './boonzeBlue3/boonzeBlue3'
import BoonzeBlue4 from './boonzeBlue4/boonzeBlue4';
import BoonzeBlue5 from './boonzeBlue5/boonzeBlue5';
import BoonzeBlue6 from './booonzeBlue6/boonzeBlue6';
export default class BoonzeBlue extends Component {
  constructor(props) {
    super(props);
  }
  
  render() {
    return (
        <>
     <BoonzeBlue1 />
     <BoonzeBlue2 />
     <BoonzeBlue3 />
     <BoonzeBlue4 />
     <BoonzeBlue5 />
     <BoonzeBlue6 />
     </>
    )
  }
}
