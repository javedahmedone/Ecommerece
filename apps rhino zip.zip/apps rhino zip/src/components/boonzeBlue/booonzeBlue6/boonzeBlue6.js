import React, { Component } from 'react';
import './boonzeBlue6.scss'
export default class BoonzeBlue6 extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div className='boonze-6'>
        <div className="container-fluid">
          <div className="row">
            <div className='col-12 col-md-12 top-div-boonze-6'>
            </div>
            <div className='col-12 col-md-12'>
              <div className='row'>
                <div className='col-6 col-md-6'>
                  <div className='row'>
                    <div className='col-10 col-md-10 offset-1 content-boonze-6'>
                      <b>Download Apps</b>
                    </div>
                    <div className='col-10 col-md-10 offset-1 content2-boonze-6'>
                      <b>Android | iOS</b>
                    </div>
                    <div className='col-10 col-md-10 offset-1'>
                       <div className='row'>
                         <div className='col-5 col-md-5 app-store'>
                           <div className='row'>
                             <div className='col-3 col-md-3 '>
                               <img src='app-store.png' />
                             </div>
                             <div className='col-9 col-md-9 store'>
                             <b>Get it on App Store</b>
                             </div>
                           </div>
                         </div>
                         <div className='col-5 col-md-5 offset-1 app-store'>
                           <div className='row'>
                             <div className='col-3 col-md-3'>
                               <img className='img-fluid' src='android.png' />
                             </div>
                             <div className='col-9 col-md-9 store'>
                            <b>Get it on Play Store</b>
                             </div>
                           </div>
                         </div>
                       </div>
                    </div>
                    <div className='col-10 col-md-10 offset-1 mt-4 content2-boonze-6'>
                      <b>We can also send the link</b>
                    </div>
                    <div className='col-10 col-md-10 offset-1 '>
                    <input type="submit" className="btn-boonze-6" value="Send me the Link" />               
                   </div>
                  </div>
                </div>
                <div className='col-6 col-md-6'>
                  <img className='img-fluid' src='hardik-sharma-CrPAvN29Nhs-unsplash.png' />
                </div>
              </div>
            </div>
            <div className='col-12 col-md-12 bottom-div-boonze-6'>
            </div>
          </div>
        </div>
      </div>
    )
  }
}
