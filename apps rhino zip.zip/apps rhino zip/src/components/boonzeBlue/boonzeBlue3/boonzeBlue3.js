import React, { Component } from 'react';
import './boonzeBlue3.scss'
export default class BoonzeBlue3 extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div className='boonze-3'>
        <div className="container">
          <div className="row">
            <div className='col-12 col-md-12 heading-boonze-3'>
              <b>Yes, we!</b>
            </div>
            <div className='col-12 col-md-4 mt-4 pt-4 content-boonze-3'>
              <div className='row'>
                <div className='col-12 col-md-12 img-boonze-1'>
                  <img src='alexandar-todov-AMzC2RVurO4-unsplash.png' />
                </div>
                <div className='col-12 col-md-12 mt-4' style={{ textAlign: "center" }} >
                  <b>are 24*7 available</b>
                  <hr />
                </div>
                <div className='col-12 col-md-12 mt-4' style={{ textAlign: "center" }} >
                  Lorem ipsum dolor sit amet, consetetur sadipscing elitr,
                  sed diam nonumy eirmod tempor invidunt ut labore et dolore
                  magna aliquyam erat, sed diam voluptua. At vero eos et accusam et
                  justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata
                  sanctus est Lorem ipsum dolor sit amet.
                  </div>
              </div>
            </div>

            <div className='col-12 col-md-4 mt-4 pt-4 content-boonze-3'>
              <div className='row'>
                <div className='col-12 col-md-12 img-boonze-1'>
                  <img src='andres-haro-dominguez-6vblFOPno18-unsplash (2).png' />
                </div>
                <div className='col-12 col-md-12 mt-4' style={{ textAlign: "center" }} >
                  <b>have wide Variety</b>
                  <hr />
                </div>
                <div className='col-12 col-md-12 mt-4' style={{ textAlign: "center" }} >
                  Lorem ipsum dolor sit amet, consetetur sadipscing elitr,
                  sed diam nonumy eirmod tempor invidunt ut labore et dolore
                  magna aliquyam erat, sed diam voluptua. At vero eos et accusam et
                  justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata
                  sanctus est Lorem ipsum dolor sit amet.
                  </div>
              </div>
            </div>

            <div className='col-12 col-md-4 mt-4 pt-4 content-boonze-3'>
              <div className='row'>
                <div className='col-12 col-md-12 img-boonze-1'>
                  <img src='evelyn-paris-HNQtAXnQlKA-unsplash (2).png' />
                </div>
                <div className='col-12 col-md-12 mt-4' style={{ textAlign: "center" }} >
                  <b>deliver at your doorstep</b>
                  <hr />
                </div>
                <div className='col-12 col-md-12 mt-4' style={{ textAlign: "center" }} >
                  Lorem ipsum dolor sit amet, consetetur sadipscing elitr,
                  sed diam nonumy eirmod tempor invidunt ut labore et dolore
                  magna aliquyam erat, sed diam voluptua. At vero eos et accusam et
                  justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata
                  sanctus est Lorem ipsum dolor sit amet.
                  </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    )
  }
}
