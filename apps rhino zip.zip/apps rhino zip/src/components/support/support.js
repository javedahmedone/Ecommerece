import React from 'react'
import { useParams } from 'react-router-dom';
import { Link } from "react-router-dom";
import './support.scss'
import SupportPlatform from './supportPlatform/supportPlatform';
import SupportYour from './supportYour/supportYour'

export default function Analytics() {
  const { type } = useParams();

    return (
      <div className="support-body">
        <div className="container-fluid">
          <div className="content-div">
            <div className="row">
              <div className="col-6 col-md-auto">Support Tickets</div>
              <div className="col-1 col-md-auto ml-auto">
                <span className="material-icons" style={{cursor:"pointer"}}>
                  search
                </span>
              </div>
              <div className="col-1 col-md-auto">
                <span className="material-icons" style={{cursor:"pointer"}}>
                  delete
                
                </span>
              </div>
              <div class="col-1 col-md-auto ">                
                <span className="material-icons"  data-toggle="dropdown" style={{ cursor: "pointer" }}>
                  filter_alt
                </span>           
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                  <a class="dropdown-item" href="#">Action</a>
                  <a class="dropdown-item" href="#">Another action</a>
                  <a class="dropdown-item" href="#">Something else here</a>
                </div>
              </div>
              <div className="col-1 col-md-auto">
                <span className="material-icons" data-toggle="dropdown" style={{ cursor: "pointer" }}>
                  more_vert
                </span>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                  <a class="dropdown-item" href="#">More Actions</a>
                </div>
              </div>
            </div>
          </div>
          <div className="content-bottom">
          <div className="row">
            <Link to="/support/platform-users" style={{ textDecoration: 'none', color: "#616161" }}><div className="col-6 col-md-auto">Platform Users</div></Link>
            <Link to="/support/your-tickets" style={{ textDecoration: 'none', color: "#616161" }}><div className="col-6 col-md-auto">Your Tickets</div></Link>
          </div>
        </div>

        <div>
          {type === 'platform-users' && <SupportPlatform />}
          {type === 'your-tickets' && <SupportYour />}
             </div>

       </div>

      </div>
    )
  }

