import React, { Component } from 'react'
// import './support.scss'
import DeleteAlert from '../../deleteAlert'
import CheckboxAll from '../../checkboxAll';

export default class SupportPlatform extends Component {
  constructor(props) {
    super(props);
    this.state = {
      user: [
        {
          id:"1",
          name: "Vance Legros",
          role: "Customer",
          subject: "System",
          status: "On-hold",
          phone: "191-814-5090 x1451",
          location: "Port Keanu",
          activeness: "Visitor"
        },
        {
          id:"2",
          name: "Kacey Kohler",
          role: "Customer",
          subject: "System",
          status: "Pending",
          phone: "(431) 281-0721",
          location: "Port Asha",
          activeness: "Returning"
        },
        {
          id:"3",
          name: "Cloyd Russel",
          role: "Delivery Person",
          subject: "Other",
          status: "Pending",
          phone: "924-834-2677 x448",
          location: "Port Ella",
          activeness: "Dormant"
        },
        {
          id:"4",
          name: "Vance Legros",
          role: "Store Owner",
          subject: "Other",
          status: "Resolve",
          phone: "191-814-5090 x1451",
          location: "Port Keanu",
          activeness: "Visitor"
        },
        { id:"5",
          name: "Kacey Kohler",
          role: "Store Owner",
          subject: "System",
          status: "Open",
          phone: "(431) 281-0721",
          location: "Port Asha",
          activeness: "Returning"
        },
        { id:"6",
          name: "Cloyd Russel",
          role: "Customer",
          subject: "System",
          status: "Pending",
          phone: "924-834-2677 x448",
          location: "Port Ella",
          activeness: "Dormant"
        },
        { id:"7",
          name: "Kacey Kohler",
          role: "Customer",
          subject: "System",
          status: "Pending",
          phone: "(431) 281-0721",
          location: "Port Asha",
          activeness: "Returning"
        },
        { id:"8",
          name: "Cloyd Russel",
          role: "Delivery Person",
          subject: "Other",
          status: "Open",
          phone: "924-834-2677 x448",
          location: "Port Ella",
          activeness: "Dormant"
        },
        {
          id:"9",
          name: "Kacey Kohler",
          role: "Delivery Person",
          subject: "Other",
          status: "On-hold",
          phone: "(431) 281-0721",
          location: "Port Asha",
          activeness: "Returning"
        },
        {
          id:"10",
          name: "Cloyd Russel",
          role: "Delivery Person",
          subject: "System",
          status: "On-hold",
          phone: "924-834-2677 x448",
          location: "Port Ella",
          activeness: "Dormant"
        },
        { id:"11",
          name: "Kacey Kohler",
          role: "Customer",
          subject: "Other",
          status: "Pending",
          phone: "(431) 281-0721",
          location: "Port Asha",
          activeness: "Returning"
        },
        { id:"12",
          name: "Cloyd Russel",
          role: "Customer",
          subject: "Other",
          status: "Resolve",
          phone: "924-834-2677 x448",
          location: "Port Ella",
          activeness: "Dormant"
        },
        { id:"13",
          name: "Kacey Kohler",
          role: "Store Owner",
          subject: "System",
          status: "Pending",
          phone: "(431) 281-0721",
          location: "Port Asha",
          activeness: "Returning"
        },
        { id:"14",
          name: "Cloyd Russel",
          role: "Customer",
          subject: "System",
          status: "Pending",
          phone: "924-834-2677 x448",
          location: "Port Ella",
          activeness: "Dormant"
        },
        { id:"15",
          name: "Kacey Kohler",
          role: "Customer",
          subject: "System",
          status: "On-hold",
          phone: "(431) 281-0721",
          location: "Port Asha",
          activeness: "Returning"
        },
        { id:"16",
          name: "Cloyd Russel",
          role: "Store Owner",
          subject: "Other",
          status: "Open",
          phone: "924-834-2677 x448",
          location: "Port Ella",
          activeness: "Dormant"
        },
        { id:"17",
          name: "Kacey Kohler",
          role: "Store Owner",
          subject: "Other",
          status: "Open",
          phone: "(431) 281-0721",
          location: "Port Asha",
          activeness: "Returning"
        },
        { id:"18",
          name: "Cloyd Russel",
          role: "Delivery Person",
          subject: "Other",
          status: "Pending",
          phone: "924-834-2677 x448",
          location: "Port Ella",
          activeness: "Dormant"
        },
      ],
      showHideToggle:true,
      userDetails:{},
      openDelete:false,
    }
  }
    
  toggle = () => {
    this.setState({
      showHideToggle: !this.state.showHideToggle
    });
  }
  tableClick(item){
   this.setState({
     userDetails:item
   })
  }

  delete(e){
    this.setState({
      openDelete:true
    })
  }
  
  handleClose = () => {
    this.setState({
      openDelete: false
    })
  }

  handleAllChecked = event => {
    let user = this.state.user;
    user.forEach(users => (users.isChecked = event.target.checked));
    this.setState({ user: user });
  };
  
  handleCheckChieldElement = (event) => {
    let user = this.state.user;
    user.forEach((users) => {
      if (users.id === event.target.value)
        users.isChecked = event.target.checked;
    });
    this.setState({ user: user });
  };
  render() {
    return (
      <div className="product-body">
        <div className="container-fluid">        
          <div className="row product-main-row" >
            <div className="table-responsive col-md-8 product-table">
              <table className="col-md-12 table" >
                <thead style={{ background: "linear-gradient(90deg, #ACCBEE 0%, #E7F0FD 100%) " }}>
                  <tr className="tr-head">
                    <th scope="col">
                    <input type="checkbox" onClick={this.handleAllChecked} style={{cursor:"pointer"}}/>
                    </th>
                    <th scope="col">Name</th>
                    <th scope="col">Role</th>
                    <th scope="col">Subject</th>
                    <th scope="col">Status</th>
                  </tr>
                </thead>
                <tbody style={{ background: "#FFFFFF" }}>

                  {this.state.user.map((user) => (
                    <tr className="row-data"  onClick={()=>{this.tableClick(user)}} style={{cursor:"pointer"}}>
                      <td>
                      <CheckboxAll
                          handleCheckChieldElement={this.handleCheckChieldElement}
                          {...user}
                        />
                      </td>
                      <td>{user.name}</td>
                      <td>{user.role}</td>
                      <td>{user.subject}</td>
                      <td>{user.status}</td>
                    </tr>
                  ))}
                </tbody>
              </table>

            </div>

            <div className="col-md-4 product-card" style={{ height: "720px", marginTop: "20px" }}>
              <div className="product-top-div">
                <div className="row">
                  <div className="col-auto col-md-auto">Ticket Details</div>
                  <div className="col-1 col-md-auto ml-auto">
                      {this.state.showHideToggle &&                 
                        <div >
                          <span className="material-icons" style={{ cursor: "pointer" }} onClick={this.toggle}>
                            toggle_on
                          </span>
                        </div> 
                      }
                      {!this.state.showHideToggle &&                 
                        <div>
                          <span className="material-icons" style={{ cursor: "pointer" }} onClick={this.toggle}>
                            toggle_off
                          </span>
                        </div> 
                      }
                    </div>  
                  <div className="col-1 col-md-auto">
                    <span className="material-icons">
                      edit_note
                    </span>
                  </div>
                  <div className="col-1 col-md-auto">
                    <span className="material-icons" onClick={this.delete.bind(this)} style={{cursor:"pointer"}}>
                      delete
                    </span>
                    <DeleteAlert open={this.state.openDelete} close={this.handleClose} />
                  </div>
                </div>
              </div>
              
              <div className="product-body-div mb-6">
                <div className="mt-3" style={{ fontWeight: "700" }}>Raised By:</div>
                <div className="row mt-2">
                  <div className="col-auto" style={{ fontWeight: "700" }}>Name:</div>
                  <div className="col-auto">{this.state.userDetails.name}</div>
                </div>
                <div className="row mt-2">
                  <div className="col-auto" style={{ fontWeight: "700" }}>M:</div>
                  <div className="col-auto">{this.state.userDetails.phone}</div>
                </div>
                <div className="row mt-2">
                  <div className="col-auto" style={{ fontWeight: "700" }}>Address:</div>
                  <div className="col-auto">27 A, New Street, Near new Café, <br /> California, USA, 787801</div>
                </div>
                <div className="row mt-2">
                  <div className="col-auto" style={{ fontWeight: "700" }}>Against:</div>
                  <div className="col-auto">Delivery Person</div>
                </div>
                <div className="row mt-2">
                  <div className="col-auto" style={{ fontWeight: "700" }}>Date:</div>
                  <div className="col-auto">31 Aug 2020  </div>
                </div>
                <div className="row mt-2">
                  <div className="col-auto" style={{ fontWeight: "700" }}>Last Order:</div>
                  <div className="col-auto">11 September 2021</div>
                </div>
                <div className="row mt-2">
                  <div className="col-auto" style={{ fontWeight: "700" }}>Subject:</div>
                  <div className="col-auto">Order {this.state.userDetails.status}</div>
                </div>
                <div className="row mt-2">
                  <div className="col-auto" style={{ fontWeight: "700" }}>Description</div>
                  <div className="col-auto">Driver refused to come to my doorstep and taken
                  the order back when i insisted again and again.
                   Please refund my order amount as soon as possible.</div>
                </div>
                <div className="row mt-4">
                  <div className="col-auto" style={{ fontWeight: "700" }}>Order Details</div>
                </div>
                <div className="row mt-2">
                  <div className="col-auto col-md-9">1. Baccardi White Rum (750 ML)</div>
                  <div className="col-auto col-md-3" style={{ textAlign: "right" }}>$ 95 </div>
                </div>
                <div className="row mt-2">
                  <div className="col-auto col-md-9">2. LIT- Gin, Vodka, Rum (500 ML) </div>
                  <div className="col-auto col-md-3" style={{ textAlign: "right" }}>$ 60</div>
                </div>
                <hr />
                <div className="row mt-2">
                  <div className="col-auto col-md-9">Total</div>
                  <div className="col-auto col-md-3" style={{ textAlign: "right" }}><b>$ 235.58</b></div>
                </div>

                <div className="row mt-2">
                  <div className="col-auto col-md-3"><b>Status</b></div>
                  <div className="col-auto col-md-2 offset-4 mr-2" style={{ textAlign: "right" }}>Pending</div>
                  <div className="col-auto col-md-2" style={{ textAlign: "right", color: "#005fff" }}>Change</div>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    )
  }
}
