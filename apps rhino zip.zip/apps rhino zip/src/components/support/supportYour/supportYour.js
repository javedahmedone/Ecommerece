import React, { Component } from 'react';
import './supportYour.scss';
import history from '../../history';

export default class SupportYour extends Component {
  constructor(props) {
    super(props)
    this.state = {

      userDetails: {},
      openDelete: false,
    }
  }

  delete(e) {
    this.setState({
      openDelete: true
    })
  }

  handleClose = () => {
    this.setState({
      openDelete: false
    })
  }

  send = () => {
    history.push('/boonze-blue')
  }

  track = () => {
    history.push('/boonze-blue')
  }
  render() {
    const { history } = this.props
    return (
      <div className="your-body">
        <div className="container-fluid">
          <div className="row">
            <div className="col-12 col-md-8">
              <div className="row">
                <div className="col-12 col-md-12 mt-2 your-heading1">
                  <b>Raise New Ticket</b>
                </div>

                <div className="col-12 col-md-12 custom-content">
                  <div className="row">
                    <div className='col-12 col-md-12'>
                      <img alt="postcard" src="postcard.png" style={{width:"max-content"}}/>
                    </div>
                    <div className="col-12 col-md-12 mt-4 pt-4">
                      <div className="row">
                        <div className="col-6 col-md-4">
                          <input type="text" className="form-control input-your-subject" placeholder="Subject" />
                        </div>
                      </div>
                    </div>

                    <div className="col-12 col-md-12 mt-4">
                      <div className="row">
                        <div className="col-12 col-md-8">
                          <div className="row">
                            <div className="col-12 col-md-12">
                            <input type="text" className="form-control input-your" placeholder="Your Concern Goes here..." />

                            </div>
                            <div className="col-12 col-md-12">
                            <input type="text" className="form-control input-your" />

                            </div>
                            <div className="col-12 col-md-12">
                            <input type="text" className="form-control input-your" />

                            </div>
                            <div className="col-6 col-md-6">
                            <input type="text" className="form-control input-your" />

                            </div>
                          </div>
                        </div>

                        <div className="col-12 col-md-4 mt-4 pt-4">
                          <div className="row">
                            <div className="col-12 col-md-12">
                              <b>To,</b>
                            </div>
                            <div className="col-12 col-md-12">
                              Support@appsrhino.com
                            </div>
                            <div className="col-12 col-md-12">
                             Managed by Relinns Technologies
                            </div>
                            <div className="col-12 col-md-12">
                             D-151,2nd Floor, Phase  8
                            </div>
                            <div className="col-12 col-md-12">
                             Mohali, Punjab, India, 160071
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="col-12 col-md-12 mt-4 pt-4">
                      <div className="row">
                        <div className="col-2 col-md-auto ml-auto">
                          Cancel
                        </div>
                        <div className="col-4 col-md-auto">
                          <input type="submit" className="custom-button" value="Send" onClick={this.send}  />
                        </div>
                      </div>
                    </div>


                  </div>
                </div>
              </div>
            </div>


            <div className='col-12 col-md-4 side-content-your'>
              <div className='row'>
                <div className="col-12 col-md-12 mt-2">
                  <div className="row">
                    <div className="col-12 col-md-12 help-your">
                      <div className="row">
                        <div className="col-12 col-md-auto">
                          <b>Track Your Ticket</b>
                        </div>
                      </div>
                    </div>
                    <div className="col-12 col-md-12 pre-content">
                      <div className="row">
                        <div className="col-md-12 ">
                          <b>Select Ticket</b>
                        </div>

                        <div className="col-md-12 mt-2">
                          <select id="" className="dropdown your-dropdown">
                            <option value="48">BT67670098</option>
                            <option value="60">Test Test Test Test Test</option>
                            <option value="68">Assets</option>
                            <option value="262">WebServices Test test test test test tes</option>
                            <option value="451">Test Icon 1</option>
                            <option value="2319">Test New Icon</option>
                            <option value="2378">English language</option>
                            <option value="5073">CAR</option>
                            <option value="5323">Testing123</option>
                            <option value="6837">Test New Icon1</option>
                          </select>
                        </div>


                        <div className="col-md-12 mt-4 pt-2">
                          <div className="row">
                            <div className='col-2 col-md-auto ml-auto' style={{ color: "#005FFF" }}>
                              Cancel
                            </div>
                            <div className="col-4 col-md-auto">
                              <input type="submit" className="your-button" value="Track"onClick={this.track} />
                            </div>
                          </div>
                        </div>

                        <div className="col-md-12 mt-2 ">
                          <hr />
                        </div>

                        <div className="col-md-12 mt-2 ">
                          <b> Ticket No:</b> BT67670098
                        </div>

                        <div className="col-md-12 mt-2">
                          <b>  Status:</b> Hi Admin, Your issues regarding the new payment feature has been
                         resolved. Cheer!<br />
                        Thanks for your valuable feedback. Hoe you are enjoying the platform.<br />
                        Please feel free to reach in case of any questions or concerns. <br />
                        Thanks<br />
                         Team AppsRhino

                            </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>


    )
  }
}
