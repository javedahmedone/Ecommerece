import React from 'react';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import TextField from '@material-ui/core/TextField';
import { useHistory } from 'react-router';
import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
  form: {
    marginLeft:"20%",
    width: '50%',
    marginTop: theme.spacing(1),
    color: '#ffffff',
  },
}));
export default function EditUser(props) {
  const classes = useStyles();
  const history = useHistory()
  const redirectLogin = () => {
    history.push('/login')
  }
  return (
    <div >
      <Dialog open={props.open} onClose={props.close}
      >
        <DialogContent>
          <DialogContentText id="alert-dialog-slide-title">
          <h2 style={{textAlign:"center"}}>Add Content</h2>
          </DialogContentText>
        </DialogContent>
        <hr />
        <form className={classes.form} noValidate>
          <TextField className={classes.text}
            margin="normal"
            fullWidth
            id="product-name"
            label="Product Name"
            type="text"
            name="product-name"
          // onChange={this.email}

          />
          <TextField className={classes.text}

            margin="normal"
            fullWidth
            name="catagory"
            label="Catagory"
            type="text"
            id="catagory"
          // onChange={this.password}
          />
          <TextField className={classes.text}

            margin="normal"
            fullWidth
            name="catalogue"
            label="Catalogue"
            type="text"
            id="catalogue"
          // onChange={this.password}
          />
        </form>
        <DialogActions>
          <Button color="primary">
            Save
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}
