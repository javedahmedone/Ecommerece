import React, { Component } from 'react'
import './User.scss'
import DeleteAlert from '../deleteAlert'
import CheckboxAll from '../checkboxAll';
export default class User extends Component {
  constructor(props) {
    super(props);
    this.state = {
      user: [
        {
          id: "1",
          name: "Vance Legros",
          phone: "191-814-5090 x1451",
          location: "Port Keanu",
          activeness: "Visitor"
        },
        {
          id: "2",
          name: "Kacey Kohler",
          phone: "(431) 281-0721",
          location: "Port Asha",
          activeness: "Returning"
        },
        {
          id: "3",
          name: "Cloyd Russel",
          phone: "924-834-2677 x448",
          location: "Port Ella",
          activeness: "Dormant"
        },
        {
          id: "4",
          name: "Vance Legros",
          phone: "191-814-5090 x1451",
          location: "Port Keanu",
          activeness: "Visitor"
        },
        {
          id: "5",
          name: "Kacey Kohler",
          phone: "(431) 281-0721",
          location: "Port Asha",
          activeness: "Returning"
        },
        {
          id: "6",
          name: "Cloyd Russel",
          phone: "924-834-2677 x448",
          location: "Port Ella",
          activeness: "Dormant"
        },
        {
          id: "7",
          name: "Kacey Kohler",
          phone: "(431) 281-0721",
          location: "Port Asha",
          activeness: "Returning"
        },
        {
          id: "8",
          name: "Cloyd Russel",
          phone: "924-834-2677 x448",
          location: "Port Ella",
          activeness: "Dormant"
        },
        {
          id: "9",
          name: "Kacey Kohler",
          phone: "(431) 281-0721",
          location: "Port Asha",
          activeness: "Returning"
        },
        {
          id: "10",
          name: "Cloyd Russel",
          phone: "924-834-2677 x448",
          location: "Port Ella",
          activeness: "Dormant"
        },
        {
          id: "11",
          name: "Kacey Kohler",
          phone: "(431) 281-0721",
          location: "Port Asha",
          activeness: "Returning"
        },
        {
          id: "12",
          name: "Cloyd Russel",
          phone: "924-834-2677 x448",
          location: "Port Ella",
          activeness: "Dormant"
        },
        {
          id: "13",
          name: "Kacey Kohler",
          phone: "(431) 281-0721",
          location: "Port Asha",
          activeness: "Returning"
        },
        {
          id: "14",
          name: "Cloyd Russel",
          phone: "924-834-2677 x448",
          location: "Port Ella",
          activeness: "Dormant"
        },
        {
          id: "15",
          name: "Kacey Kohler",
          phone: "(431) 281-0721",
          location: "Port Asha",
          activeness: "Returning"
        },
        {
          id: "16",
          name: "Cloyd Russel",
          phone: "924-834-2677 x448",
          location: "Port Ella",
          activeness: "Dormant"
        },
        {
          id: "17",
          name: "Kacey Kohler",
          phone: "(431) 281-0721",
          location: "Port Asha",
          activeness: "Returning"
        },
        {
          id: "18",
          name: "Cloyd Russel",
          phone: "924-834-2677 x448",
          location: "Port Ella",
          activeness: "Dormant"
        },
      ],
      showHideToggle:true,
      userDetails: {},
      openDelete: false,
      showHide: false,
    }
  }
  
  toggle = () => {
    this.setState({
      showHideToggle: !this.state.showHideToggle
    });
  }
  
  tableClick(item) {
    this.setState({
      userDetails: item
    })
  }

  delete(e) {
    this.setState({
      openDelete: true
    })
  }

  handleClose = () => {
    this.setState({
      openDelete: false
    })
  }

  handleAllChecked = event => {
    let user = this.state.user;
    user.forEach(users => (users.isChecked = event.target.checked));
    this.setState({ user: user });
  };

  handleCheckChieldElement = (event) => {
    let user = this.state.user;
    user.forEach((users) => {
      if (users.id === event.target.value)
        users.isChecked = event.target.checked;
    });
    this.setState({ user: user });
  };

  search = () => {
    this.setState({
      showHide: !this.state.showHide
    });
  }

  render() {
    return (
      <div className="product-body">
        <div className="container-fluid">
          <div className="content-div">
            <div className="row">
              <div className="col-1 col-md-auto">Users</div>
              <div>
                {this.state.showHide &&
                  <div className="col-1 col-md-auto ml-auto mt-0 search">
                    <form class="form-inline">
                      <input class="form-control"
                        type="search"
                        placeholder="Search"
                        aria-label="Search"
                        style={{ cursor: "pointer", fontSize: "12px" }} />
                    </form>
                  </div>
                }
              </div>
              <div className="col-1 col-md-auto ml-auto">
                <span className="material-icons" style={{ cursor: "pointer" }} onClick={this.search}>
                  search
                </span>
              </div>
              <div className="col-1 col-md-auto ">
                <span className="material-icons" onClick={this.delete.bind(this)} style={{ cursor: "pointer" }}>
                  delete
                </span>
                <DeleteAlert open={this.state.openDelete} close={this.handleClose} />
              </div>
              <div class="col-1 col-md-auto ">
                <span className="material-icons" data-toggle="dropdown" style={{ cursor: "pointer" }}>
                  filter_alt
                </span>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                  <a class="dropdown-item" href="#">Action</a>
                  <a class="dropdown-item" href="#">Another action</a>
                  <a class="dropdown-item" href="#">Something else here</a>
                </div>
              </div>
              <div className="col-1 col-md-auto">
                <span className="material-icons" data-toggle="dropdown" style={{ cursor: "pointer" }}>
                  more_vert
                </span>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                  <a class="dropdown-item" href="#">More Actions</a>
                </div>
              </div>
            </div>
          </div>

          <div className="content-bottom">
            <div className="row">
              <div className="col-6 col-md-auto">Customers (6k)</div>
              <div className="col-6 col-md-auto">Stores (576)</div>
              <div className="col-6 col-md-auto">Delivery Persons (1K)</div>
              <div className="col-6 col-md-auto">Sub Admin (5)</div>
            </div>
          </div>

          <div className="row product-main-row" >
            <div className="table-responsive col-md-8 product-table">
              <table className="col-md-12 table" >
                <thead style={{ background: "linear-gradient(90deg, #ACCBEE 0%, #E7F0FD 100%) " }}>
                  <tr className="tr-head">
                    <th scope="col">
                      <input type="checkbox" onClick={this.handleAllChecked} style={{ cursor: "pointer" }} />
                    </th>
                    <th scope="col">Name</th>
                    <th scope="col">Phone</th>
                    <th scope="col">Location</th>
                    <th scope="col">Activeness</th>
                  </tr>
                </thead>
                <tbody style={{ background: "#FFFFFF" }}>

                  {this.state.user.map((users) => (
                    <tr className="row-data" onClick={() => { this.tableClick(users) }} style={{ cursor: "pointer" }}>
                      <td>
                        <CheckboxAll
                          handleCheckChieldElement={this.handleCheckChieldElement}
                          {...users}
                        />
                      </td>
                      <td key={users.id}>{users.name}</td>
                      <td key={users.id}>{users.phone}</td>
                      <td key={users.id}>{users.location}</td>
                      <td key={users.id}>{users.activeness}</td>
                    </tr>
                  ))}
                </tbody>
              </table>

            </div>
            <div className="col-md-4 product-card" style={{ height: "720px", marginTop: "20px" }}>
              <div className="product-top-div">
                <div className="row">
                  <div className="col-auto col-md-auto">Customer Details</div>
                  <div className="col-1 col-md-auto ml-auto">
                      {this.state.showHideToggle &&                 
                        <div >
                          <span className="material-icons" style={{ cursor: "pointer" }} onClick={this.toggle}>
                            toggle_on
                          </span>
                        </div> 
                      }
                      {!this.state.showHideToggle &&                 
                        <div>
                          <span className="material-icons" style={{ cursor: "pointer" }} onClick={this.toggle}>
                            toggle_off
                          </span>
                        </div> 
                      }
                    </div>      
                  <div className="col-1 col-md-auto">
                    <span className="material-icons">
                      edit_note
                    </span>
                  </div>
                  <div className="col-1 col-md-auto">
                    <span className="material-icons" style={{ cursor: "pointer" }} onClick={this.delete.bind(this)}>
                      delete
                    </span>
                  </div>
                </div>
              </div>
              <div className="product-body-div">
                <div className="text-center">
                  <img src="user.jpg" style={{ height: "175px", width: "175px", padding: "10px", backgroundColor: "white" }} alt="User" />

                </div>
                <div className="mt-3 text-center" style={{ fontWeight: "700" }}>Jane Peterson</div>

                <div className="row mt-2">
                  <div className="col-auto" style={{ fontWeight: "700" }}>Name:</div>
                  <div className="col-auto">{this.state.userDetails.name}</div>
                </div>
                <div className="row mt-2">
                  <div className="col-auto" style={{ fontWeight: "700" }}>M:</div>
                  <div className="col-auto">{this.state.userDetails.phone}</div>
                </div>
                <div className="row mt-2">
                  <div className="col-auto" style={{ fontWeight: "700" }}>Address:</div>
                  <div className="col-auto">California, USA, 787801</div>
                </div>
                <div className="row mt-2">
                  <div className="col-auto" style={{ fontWeight: "700" }}>Age:</div>
                  <div className="col-auto">31</div>
                </div>
                <div className="row mt-2">
                  <div className="col-auto" style={{ fontWeight: "700" }}>Joined On:</div>
                  <div className="col-auto">31 August 2020</div>
                </div>
                <div className="row mt-2">
                  <div className="col-auto" style={{ fontWeight: "700" }}>Last Order:</div>
                  <div className="col-auto">11 September 2021</div>
                </div>
                <div className="row mt-2">
                  <div className="col-auto" style={{ fontWeight: "700" }}>Total no. of orders:</div>
                  <div className="col-auto">17</div>
                </div>
                <div className="row mt-2">
                  <div className="col-auto" style={{ fontWeight: "700" }}>Avg order size:</div>
                  <div className="col-auto">90 USD</div>
                </div>
                <div className="row mt-2">
                  <div className="col-auto" style={{ fontWeight: "700" }}>Activeness:</div>
                  <div className="col-auto">{this.state.userDetails.activeness}</div>
                </div>
                <div className="row mt-2">
                  <div className="col-auto" style={{ fontWeight: "700" }}>Favorites:</div>
                </div>
                <div className="row mt-2">
                  <div className="col-auto">1</div>
                  <div className="col-auto">Baccardi White Rum</div>
                  <div className="col-auto">250 ML</div>
                </div>
                <div className="row mt-2">
                  <div className="col-auto">2</div>
                  <div className="col-auto">Red Wine</div>
                  <div className="col-auto">250 ML</div>
                </div>
                <div className="row mt-2">
                  <div className="col-auto">3</div>
                  <div className="col-auto">Jameson Whiskey</div>
                  <div className="col-auto">250 ML</div>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    )
  }
}
