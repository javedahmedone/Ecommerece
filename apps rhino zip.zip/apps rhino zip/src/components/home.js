import React, { Component } from 'react';
import './home.scss'
import './homeResponsive.scss'
import history from './history'
class Home extends Component {
  constructor(props) {
    super(props);
    this.state = {
    }
  }
  submit = () => {
    history.push('/dashboard')
  }
  render() {
    const { history } = this.props
    return (
      <>
        <div className="container-fluid">
          <div className="row">
            <div className="col-md-6">
              <div className="image">
                <div className="content1"><b>AppsRhino Welcomes you back!</b>

                  <div className='login'>
                    <div className="text-login">
                      Login
                      </div>

                    <div className="form-login" >
                      <form>
                        <input className=' form-control in'
                          id='emailLogin'
                          type='email'
                          aria-describedby="emailHelp"
                          placeholder="Email"
                          value={this.state.email}
                          onChange={this.email} />


                        <input className=' form-control in'
                          id='passwordLogin'
                          type='password'
                          aria-describedby="passwordHelpInline"
                          placeholder="Password"
                          value={this.state.password}
                          onChange={this.password} required />

                        <div className="forgot">
                          <span className=""> Forgot Password</span>
                          <span ><input type="submit" className="btlogin" value="Login" onClick={this.submit} /></span>
                        </div>


                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-1">
              <div className="row">
                <div className="col-md-12">
                  <div className="vl"></div>
                </div>
                <div className="col-md-12">
                  <div className="or"><b>Or</b></div>
                </div>
                <div className="col-md-12">
                  <div className="vl2">

                  </div>
                </div>
              </div>

            </div>
            <div className="col-md-3">
              <div className="row">
                <div className="col-md-12">
                  <div className="content2 " >
                    <b>  New User... Sign up Please</b>
                    <div className='signup'>
                      <div className="text-signup">Sign Up </div>
                      <div className="form-signup" >
                        <form>
                          <input className=' form-control in'
                            id='name'
                            type='text'
                            placeholder="Name"
                            value={this.state.name}
                            onChange={this.name} required />


                          <input className=' form-control in'
                            id='emailSignup'
                            type='email'
                            aria-describedby="emailHelp"
                            placeholder="Email"
                            value={this.state.email}
                            onChange={this.email} required />
                          <div className="row">
                            <div className="col-md-4">
                              <input className=' form-control in'
                                id='countrySignup'
                                type='text'
                                placeholder="Country"
                                value={this.state.country}
                                onChange={this.country} required />
                            </div>
                            < div className="col-md-8">
                              <input className=' form-control in sml'
                                id='mobileSignup'
                                type='text'
                                placeholder="Mobile No."
                                value={this.state.country}
                                onChange={this.country} required />
                            </div>
                          </div>
                          <div className='form-group '>
                            <input className=' form-control in'
                              id='address'
                              type='text'
                              placeholder="Address"
                              value={this.state.address}
                              onChange={this.address} required />
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-md-12">
                  <div className='other-details'>

                    <div className=" form-other-details" >
                      <form>
                        <input className=' form-control in'
                          id='singupPassword'
                          type='password'
                          placeholder="Password"
                          value={this.state.password}
                          onChange={this.password} required />


                        <input className=' form-control in'
                          id='confirmPassword'
                          type='password'
                          placeholder="Confirm Password"
                          value={this.state.password}
                          onChange={this.password} required />
                        <div className="privacy">
                          <span> Privacy Policy and T&C</span>
                          <span> <input type="submit" className="btsignup" value="Sign Up" onClick={this.submit} /></span>
                          <div className="terms">
                            By Signing up, You will be agree to our privacy policy and
                            Terms and Conditions
                        </div>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </>
    )
  }
}


export default Home;