import React from 'react';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import { useHistory } from 'react-router';
export default function DeleteAlert(props) {
  const history = useHistory()
  const redirectLogin = () => {
    history.push('/login')
  }
  return (
    <div >
      <Dialog open={props.open} onClose={props.close}
      >
        <DialogContent>
          <DialogContentText id="alert-dialog-slide-description">
            Do you want to process
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button color="primary">
            Yes
          </Button>
          <Button color="primary">
            No
          </Button>

        </DialogActions>
      </Dialog>
    </div>
  );
}
