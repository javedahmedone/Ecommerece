import React, { Component } from 'react'
import './Content.scss';
import DeleteAlert from '../deleteAlert';
import AddDetailsAlert from './addDetailsAlert';
import CheckboxAll from '../checkboxAll';
export default class Content extends Component {
  constructor(props) {
    super(props);
    this.state = {
      product: [
        {
          id:"1",
          name: "Tonto",
          category: "Sato",
          catalogue: "Food",
          availablity: "In-Stock",
          isChecked: false
        },
        {
          id:"2",
          name: "Tonto",
          category: "Sato",
          catalogue: "Food",
          availablity: "In-Stock",
          isChecked: false
        },
        {
          id:"3",
          name: "Wine",
          category: "Sonti",
          catalogue: "Meat",
          availablity: "In-Stock",
          isChecked: false
        },
        {
          id:"4",
          name: "Marsala",
          category: "Barley",
          catalogue: "Food",
          availablity: "Out of stock",
          isChecked: false
        },
        {
          id:"5",
          name: "Tonto",
          category: "Sato",
          catalogue: "Food",
          availablity: "In-Stock",
          isChecked: false
        },
        {
          id:"6",
          name: "Marsala",
          category: "Barley",
          catalogue: "Food",
          availablity: "Out of stock",
          isChecked: false
        },
        {
          id:"7",
          name: "Tonto",
          category: "Sato",
          catalogue: "Food",
          availablity: "In-Stock",
          isChecked: false
        },
        {
          id:"8",
          name: "Marsala",
          category: "Barley",
          catalogue: "Food",
          availablity: "Out of stock",
          isChecked: false
        },
        {
          id:"9",
          name: "Tonto",
          category: "Sato",
          catalogue: "Food",
          availablity: "In-Stock",
          isChecked: false
        },
        {
          id:"10",
          name: "Marsala",
          category: "Barley",
          catalogue: "Food",
          availablity: "Out of stock",
          isChecked: false
        },
        {
          id:"11",
          name: "Tonto",
          category: "Sato",
          catalogue: "Food",
          availablity: "In-Stock",
          isChecked: false
        },
        {
          id:"12",
          name: "Marsala",
          category: "Barley",
          catalogue: "Food",
          availablity: "Out of stock",
          isChecked: false
        },
        {
          id:"13",
          name: "Tonto",
          category: "Sato",
          catalogue: "Food",
          availablity: "In-Stock",
          isChecked: false
        },
        {
          id:"14",
          name: "Marsala",
          category: "Barley",
          catalogue: "Food",
          availablity: "Out of stock",
          isChecked: false
        },
        {
          id:"15",
          name: "Tonto",
          category: "Sato",
          catalogue: "Food",
          availablity: "In-Stock",
          isChecked: false
        },
        {
          id:"16",
          name: "Marsala",
          category: "Barley",
          catalogue: "Food",
          availablity: "Out of stock",
          isChecked: false
        },
        {
          id:"17",
          name: "Tonto",
          category: "Sato",
          catalogue: "Food",
          availablity: "In-Stock",
          isChecked: false
        },
        {
          id:"18",
          name: "Marsala",
          category: "Barley",
          catalogue: "Food",
          availablity: "Out of stock",
          isChecked: false
        },
        {
          id:"19",
          name: "Tonto",
          category: "Sato",
          catalogue: "Food",
          availablity: "In-Stock",
          isChecked: false
        },
        {
          id:"20",
          name: "Marsala",
          category: "Barley",
          catalogue: "Food",
          availablity: "Out of stock",
          isChecked: false
        },
        {
          id:"21",
          name: "Tonto",
          category: "Sato",
          catalogue: "Food",
          availablity: "In-Stock",
          isChecked: false
        },
        {
          id:"22",
          name: "Marsala",
          category: "Barley",
          catalogue: "Food",
          availablity: "Out of stock",
          isChecked: false
        },
        {
          id:"23",
          name: "Tonto",
          category: "Sato",
          catalogue: "Food",
          availablity: "In-Stock",
          isChecked: false
        },
        {
          id:"24",
          name: "Marsala",
          category: "Barley",
          catalogue: "Food",
          availablity: "Out of stock",
          isChecked: false
        },
        {
          id:"25",
          name: "Tonto",
          category: "Sato",
          catalogue: "Food",
          availablity: "In-Stock",
          isChecked: false
        }
      ],
      showHideToggle:true,
      userDetails: {},
      openDelete: false,
      showHide: false,
      openAdd: false,
    }
  }
    
  toggle = () => {
    this.setState({
      showHideToggle: !this.state.showHideToggle
    });
  }
  tableClick(item) {
    this.setState({
      userDetails: item
    })
  }

  delete(e) {
    this.setState({
      openDelete: true
    })
  }

  handleDelete = () => {
    this.setState({
      openDelete: false
    })
  }

  add(e) {
    this.setState({
      openAdd: true
    })
  }
  handleClose = () => {
    this.setState({
      openAdd: false
    })
  }

  handleAllChecked = event => {
    let products = this.state.product;
    products.forEach(users => (users.isChecked = event.target.checked));
    this.setState({ product: products });
  };
  
  handleCheckChieldElement = (event) => {
    let product = this.state.product;
    product.forEach((products) => {
      if (products.id === event.target.value)
        products.isChecked = event.target.checked;
    });
    this.setState({ product: product });
  };
  search = () => {
    this.setState({
      showHide: !this.state.showHide
    });
  }
  render() {
    return (
      <div className="product-body">
        <div className="container-fluid">
          <div className="content-div">
            <div className="row">
              <div className="col-1 col-md-auto">Content</div>
              <div>
                {this.state.showHide &&
                  <div className="col-1 col-md-auto ml-auto mt-0 search">
                    <form class="form-inline">
                      <input class="form-control"
                        type="search"
                        placeholder="Search"
                        aria-label="Search"
                        style={{ cursor: "pointer", fontSize: "12px" }} />
                    </form>
                  </div>
                }
              </div>
              <div className="col-1 col-md-auto ml-auto">
                <span className="material-icons" style={{cursor:"pointer"}}  onClick={this.search}>
                  search
                </span>
              </div>
              <div className="col-1 col-md-auto">
                <span className="material-icons" onClick={this.add.bind(this)} style={{ cursor: "pointer" }}>
                  add_circle_outline
                </span>
                <AddDetailsAlert open={this.state.openAdd} close={this.handleClose} />
              </div>
              <div className="col-1 col-md-auto">
                <span className="material-icons" onClick={this.delete.bind(this)} style={{ cursor: "pointer" }}>
                  delete
                </span>
                <DeleteAlert open={this.state.openDelete} close={this.handleDelete} />
              </div>
              <div class="col-1 col-md-auto ">                
                <span className="material-icons"  data-toggle="dropdown" style={{ cursor: "pointer" }}>
                  filter_alt
                </span>           
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                  <a class="dropdown-item" href="#">Action</a>
                  <a class="dropdown-item" href="#">Another action</a>
                  <a class="dropdown-item" href="#">Something else here</a>
                </div>
              </div>
              <div className="col-1 col-md-auto">
                <span className="material-icons" data-toggle="dropdown" style={{ cursor: "pointer" }}>
                  more_vert
                </span>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                  <a class="dropdown-item" href="#">More Actions</a>
                </div>
              </div>
            </div>
          </div>
          <div className="content-bottom">
            <div className="row">
              <div className="col-6 col-md-auto">Catalogues (6)</div>
              <div className="col-6 col-md-auto">Locations (4)</div>
              <div className="col-6 col-md-auto">Product Category (10)</div>
              <div className="col-6 col-md-auto">Products (1090)</div>
            </div>
          </div>

          <div className="row product-main-row" >
            <div className="table-responsive col-md-8 product-table">
              <table className="col-md-12 table" >
                <thead style={{ background: "linear-gradient(90deg, #ACCBEE 0%, #E7F0FD 100%) " }}>
                  <tr className="tr-head">
                    <th scope="col">
                      <input type="checkbox" onClick={this.handleAllChecked} style={{cursor:"pointer"}}/>
                    </th>
                    <th scope="col">Product Name</th>
                    <th scope="col">Category</th>
                    <th scope="col">Catalogue</th>
                    <th scope="col">Availability</th>
                  </tr>
                </thead>
                <tbody style={{ background: "#FFFFFF" }}>

                  {this.state.product.map((product) => (
                    <tr className="row-data" onClick={() => { this.tableClick(product)}} style={{cursor:"pointer"}}>
                      <td>
                        <CheckboxAll
                          handleCheckChieldElement={this.handleCheckChieldElement}
                          {...product}
                        />
                      </td>
                      <td>{product.name}</td>
                      <td>{product.category}</td>
                      <td>{product.catalogue}</td>
                      <td>{product.availablity}</td>
                    </tr>
                  ))}
                </tbody>
              </table>

            </div>
            <div className="col-md-4 product-card" style={{ height: "720px", marginTop: "20px" }}>
              <div className="product-top-div">
                <div className="row">
                  <div className="col-auto col-md-auto">Product Details</div>
                  <div className="col-1 col-md-auto ml-auto">
                      {this.state.showHideToggle &&                 
                        <div >
                          <span className="material-icons" style={{ cursor: "pointer" }} onClick={this.toggle}>
                            toggle_on
                          </span>
                        </div> 
                      }
                      {!this.state.showHideToggle &&                 
                        <div>
                          <span className="material-icons" style={{ cursor: "pointer" }} onClick={this.toggle}>
                            toggle_off
                          </span>
                        </div> 
                      }
                    </div>  
                  <div className="col-1 col-md-auto">
                    <span className="material-icons">
                      edit_note
                    </span>
                  </div>
                  <div className="col-1 col-md-auto">
                    <span className="material-icons" onClick={this.delete.bind(this)} style={{ cursor: "pointer" }}>
                      delete
                    </span>
                  </div>
                </div>
              </div>
              <div className="product-body-div">
                <div className="text-center">
                  <img src="wine.jpg" style={{ height: "175px", width: "175px", padding: "10px" }} alt="..." />

                </div>
                <div className="mt-3 text-center" style={{ fontWeight: "700" }}>Table Wine</div>
                <div className="mt-4 text-justify">
                  Table wine is a wine term with two different meanings: a style of wine and a quality level within wine classification. In the United States, table wine primarily designates a wine style: ordinary wine which is neither fortified nor sparkling nor expensive.
                </div>
                <div className="row mt-4">
                  <div className="col-auto" style={{ fontWeight: "700" }}>Variant</div>
                  <div className="col-auto ml-auto" style={{ fontSize: "12px", color: "#005FFF" }}>Add new variants</div>
                </div>
                <div className="row mt-2">
                  <div className="col-auto">1</div>
                  <div className="col-auto ml-auto">250 ML</div>
                  <div className="col-auto ml-auto">$500</div>
                  <div className="col-auto ml-auto">10% off</div>
                  <div className="col-auto ml-auto">
                    <span class="material-icons" style={{ color: '#C70000' }}>
                      close
                    </span>
                  </div>
                </div>
                <div className="row mt-2">
                  <div className="col-auto">2</div>
                  <div className="col-auto ml-auto">250 ML</div>
                  <div className="col-auto ml-auto">$500</div>
                  <div className="col-auto ml-auto">10% off</div>
                  <div className="col-auto ml-auto">
                    <span class="material-icons" style={{ color: '#C70000' }}>
                      close
                    </span>
                  </div>
                </div>
                <div className="row mt-2">
                  <div className="col-auto">3</div>
                  <div className="col-auto ml-auto">250 ML</div>
                  <div className="col-auto ml-auto">$500</div>
                  <div className="col-auto ml-auto">10% off</div>
                  <div className="col-auto ml-auto">
                    <span class="material-icons" style={{ color: '#C70000' }}>
                      close
                    </span>
                  </div>
                </div>
                <div className="row mt-4">
                  <div className="col-auto" style={{ fontWeight: "700" }}>Locations</div>
                  <div className="col-auto ml-auto" style={{ fontSize: "12px", color: "#005FFF" }}>Add new location</div>
                </div>
                <div className="row mt-2">
                  <div className="col-auto">1</div>
                  <div className="col-auto">Chennai,India</div>
                  <div className="col-auto ml-auto">
                    <span class="material-icons" style={{ color: '#C70000' }}>
                      close
                    </span>
                  </div>
                </div>
                <div className="row mt-2">
                  <div className="col-auto">2</div>
                  <div className="col-auto">Delhi,India </div>
                  <div className="col-auto ml-auto">
                    <span class="material-icons" style={{ color: '#C70000' }}>
                      close
                    </span>
                  </div>
                </div>
                <div className="row mt-2">
                  <div className="col-auto">3</div>
                  <div className="col-auto">Mohali, Punjab, India </div>
                  <div className="col-auto ml-auto">
                    <span class="material-icons" style={{ color: '#C70000' }}>
                      close
                    </span>
                  </div>
                </div>


              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}
