import React from 'react';
import { useParams } from 'react-router-dom';
import { Link } from "react-router-dom";
import SettingsPlatform from './settingsPlatform/settingsPlatform';
import SettingsIntegration from './settingsIntegration/settingsIntegration';
import SettingsPayment from './settingsPayment/settingsPayment';
import SettingsPreference from './settingsPreference/settingsPreference';
import SettingsLegal from './settingsLegal/settingsLegal';

export default function Settings() {
  const { type } = useParams();

  return (
    <div className="product-body">
      <div className="container-fluid">
        <div className="content-div">
          <div className="row">
            <div className="col-1 col-md-auto">Settings</div>
            <div className="col-1 col-md-auto ml-auto">
              <span className="material-icons" style={{cursor:"pointer"}}>
                search
              </span>
            </div>         
          </div>
        </div>
        <div className="content-bottom">
          <div className="row">
            <Link to="/settings/platform" style={{ textDecoration: 'none', color: "#616161" }}><div className="col-6 col-md-auto">Platform</div></Link>
            <Link to="/settings/integration" style={{ textDecoration: 'none', color: "#616161" }}><div className="col-6 col-md-auto">Integration</div></Link>
            <Link to="/settings/payment" style={{ textDecoration: 'none', color: "#616161" }}><div className="col-6 col-md-auto">Payment</div></Link>
            <Link to="/settings/preference" style={{ textDecoration: 'none', color: "#616161" }}><div className="col-6 col-md-auto">Preference</div></Link>
            <Link to="/settings/legal" style={{ textDecoration: 'none', color: "#616161" }}><div className="col-6 col-md-auto">Legal</div></Link>
          
          </div>
        </div>

        <div>
          {type === 'platform' && <SettingsPlatform />}
          {type === 'integration' && <SettingsIntegration />}
          {type === 'payment' && <SettingsPayment />}
          {type === 'preference' && <SettingsPreference />}
          {type === 'legal' && <SettingsLegal />}
       
        </div>
      </div>
    </div>
  )
}
