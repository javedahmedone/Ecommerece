import React, { Component } from 'react';
import './settingsPlatform.scss'

export default class SettingsPlatform extends Component {
  constructor(props) {
    super(props)
    this.state = {
      showHide: true,
      showHideToggle1:true,
      showHideToggle2:true,
      showHideToggle3:true,
      showHideToggle4:true,
      showHideToggle5:true,
      showHideToggle6:true,
      showHideToggle7:true,
      showHideToggle8:true,
      showHideToggle9:true,
      showHideToggle10:true,
      userDetails: {},
      openDelete: false,
    }
  }

  eye = () => {
    this.setState({
      showHide: !this.state.showHide
    });
  }
  
  toggle1 = () => {
    this.setState({
      showHideToggle1: !this.state.showHideToggle1
    });
  }
  toggle2 = () => {
    this.setState({
      showHideToggle2: !this.state.showHideToggle2
    });
  }
  toggle3 = () => {
    this.setState({
      showHideToggle3: !this.state.showHideToggle3
    });
  }
  toggle4 = () => {
    this.setState({
      showHideToggle4: !this.state.showHideToggle4
    });
  }
  toggle5 = () => {
    this.setState({
      showHideToggle5: !this.state.showHideToggle5
    });
  }
  toggle6 = () => {
    this.setState({
      showHideToggle6: !this.state.showHideToggle6
    });
  }
  toggle7 = () => {
    this.setState({
      showHideToggle7: !this.state.showHideToggle7
    });
  }
  toggle8 = () => {
    this.setState({
      showHideToggle8: !this.state.showHideToggle8
    });
  }
  toggle9 = () => {
    this.setState({
      showHideToggle9: !this.state.showHideToggle9
    });
  }
  toggle10 = () => {
    this.setState({
      showHideToggle10: !this.state.showHideToggle10
    });
  }
  delete(e) {
    this.setState({
      openDelete: true
    })
  }

  handleClose = () => {
    this.setState({
      openDelete: false
    })
  }

  render() {
    return (
      <div className="platform-body">
        <div className="container-fluid">
          <div className="row">
            <div className="col-12 col-md-3">
              <div className="row">
                <div className="col-12 col-md-12 mt-2 platform-heading">
                  <div className="row">
                    <div className="col-1 col-md-auto">
                      <b>General</b>
                    </div>
                  
              <div className="col-1 col-md-auto ml-auto">
                {this.state.showHide &&                 
                    <div >
                    <span className="material-icons" style={{ cursor: "pointer" }} onClick={this.eye}>
                   visibility
                  </span>
                  </div> 
                }
                 {!this.state.showHide &&                 
                    <div>
                    <span className="material-icons" style={{ cursor: "pointer" }} onClick={this.eye}>
                    visibility_off
                  </span>
                  </div> 
                }
              </div>
                                     
                  </div>
                </div>

                <div className="col-12 col-md-12 ">
                  <div className="row">                  

                    <div className="col-12 col-md-12 int-content1">
                  <div className="row">
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-8 col-md-auto">
                          Default Dashboard
                    </div>
                        <div className="col-2 col-md-auto ml-auto" style={{color:"#005FFF"}}>
                          Analytics 
                    </div>
                    <div className="col-1 col-md-auto">
                      <span className="material-icons">
                      keyboard_arrow_down
                    </span>
                    </div>   
                      </div>
                      <hr />
                    </div>
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-8 col-md-auto">
                          Date Format
                    </div>
                        <div className="col-2 col-md-auto ml-auto" style={{color:"#005FFF"}}>
                          20 Sep 2020 
                    </div>
                    <div className="col-1 col-md-auto">
                      <span className="material-icons">
                      keyboard_arrow_down
                    </span>
                    </div>   
                      </div>
                      <hr />
                    </div>
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-8 col-md-auto">
                          Time Format
                    </div>
                        <div className="col-2 col-md-auto ml-auto" style={{color:"#005FFF"}}>
                          12 Hrs 
                    </div>
                    <div className="col-1 col-md-auto">
                      <span className="material-icons">
                      keyboard_arrow_down
                    </span>
                    </div>   
                      </div>
                      <hr />
                    </div>

                     <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-8 col-md-auto">
                          Distance Unit
                    </div>
                        <div className="col-2 col-md-auto ml-auto" style={{color:"#005FFF"}}>
                          Miles 
                    </div>
                    <div className="col-1 col-md-auto">
                      <span className="material-icons">
                      keyboard_arrow_down
                    </span>
                    </div>   
                      </div>
                      <hr />
                    </div>

                     <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-8 col-md-auto">
                          Time Zone
                    </div>
                        <div className="col-2 col-md-auto ml-auto" style={{color:"#005FFF"}}>
                          GMT+5:30 Hrs 
                    </div>
                    <div className="col-1 col-md-auto">
                      <span className="material-icons">
                      keyboard_arrow_down
                    </span>
                    </div>   
                      </div>
                      <hr />
                    </div>

                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-8 col-md-auto" style={{color:"#005FFF"}}>
                          Reset
                    </div>
                    <div className="col-4 col-md-auto ml-auto">
                          <input type="submit" className="legal-button" value="Update" />
                        </div>                   
                      </div>
                    </div>

                  </div>
                </div>

                  

                  </div>
                </div>

                <div className="col-12 col-md-12 mt-2 platform-heading2">
                  <div className="row">
                    <div className="col-1 col-md-auto">
                      <b>Task Allocation</b>
                    </div>
                    <div className="col-1 col-md-auto ml-auto">
                      <span className="material-icons">
                      edit_note
                    </span>
                    </div>                   
                  </div>
                </div>

                <div className="col-12 col-md-12 ">
                  <div className="row">                  

                    <div className="col-12 col-md-12 int-content1">
                  <div className="row">
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-8 col-md-auto">
                          Method
                    </div>
                        <div className="col-2 col-md-auto ml-auto">
                          One By One 
                    </div>
                     </div>
                      <hr />
                    </div>
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-8 col-md-auto">
                          Request Expires in
                    </div>
                        <div className="col-2 col-md-auto ml-auto">
                          1 Min 
                    </div>
                     
                      </div>
                      <hr />
                    </div>
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-8 col-md-auto">
                          No. of Retires
                    </div>
                        <div className="col-2 col-md-auto ml-auto">
                          3 
                    </div>
                      
                      </div>
                      <hr />
                    </div>

                     <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-8 col-md-auto">
                          Start Alocation before task time
                    </div>
                        <div className="col-2 col-md-auto ml-auto" >
                          3 Min 
                    </div>
                     
                      </div>
                      <hr />
                    </div>

                     <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-8 col-md-auto">
                          Search Distance
                    </div>
                        <div className="col-2 col-md-auto ml-auto">
                          5 Miles
                    </div>                      
                      </div>                     
                    </div>
                  </div>
                </div>

                  

                  </div>
                </div>
              </div>
            </div>
            <div className="col-12 col-md-5">
              <div className="col-12 col-md-12 mt-2 platform-heading3">
                  <div className="row">
                    <div className="col-1 col-md-auto">
                      <b>Notifications</b>
                    </div>
                    <div className="col-1 col-md-auto ml-auto">
                    <b>Customer App</b>
                    </div>  
                    <div className="col-1 col-md-auto">
                      <span className="material-icons">
                      keyboard_arrow_down
                    </span>
                    </div>                   
                  </div>
                </div>

                <div className="col-12 col-md-12 ">
                  <div className="row">           

                    <div className="col-12 col-md-12 int-content1">
                  <div className="row">
                
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-8 col-md-auto">
                          Task Created Successfully by Customer
                    </div>   
                    <div className="col-1 col-md-auto ml-auto">
                      {this.state.showHideToggle1 &&                 
                        <div >
                          <span className="material-icons" style={{ cursor: "pointer" }} onClick={this.toggle1}>
                            toggle_on
                          </span>
                        </div> 
                      }
                      {!this.state.showHideToggle1 &&                 
                        <div>
                          <span className="material-icons" style={{ cursor: "pointer" }} onClick={this.toggle1}>
                            toggle_off
                          </span>
                        </div> 
                      }
                    </div>            
                     
                      </div>
                      <hr />
                    </div>

                   <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-8 col-md-auto">
                          Payment is pending for the order
                    </div>                     
                    <div className="col-1 col-md-auto ml-auto">
                      {this.state.showHideToggle2 &&                 
                        <div >
                          <span className="material-icons" style={{ cursor: "pointer" }} onClick={this.toggle2}>
                            toggle_on
                          </span>
                        </div> 
                      }
                      {!this.state.showHideToggle2 &&                 
                        <div>
                          <span className="material-icons" style={{ cursor: "pointer" }} onClick={this.toggle2}>
                            toggle_off
                          </span>
                        </div> 
                      }
                    </div>    
                      </div>
                      <hr />
                    </div>
                 
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-8 col-md-auto">
                          Task Created Successfully by Customer
                    </div>                     
                    <div className="col-1 col-md-auto ml-auto">
                      {this.state.showHideToggle3 &&                 
                        <div >
                          <span className="material-icons" style={{ cursor: "pointer" }} onClick={this.toggle3}>
                            toggle_on
                          </span>
                        </div> 
                      }
                      {!this.state.showHideToggle3 &&                 
                        <div>
                          <span className="material-icons" style={{ cursor: "pointer" }} onClick={this.toggle3}>
                            toggle_off
                          </span>
                        </div> 
                      }
                    </div>     
                      </div>
                      <hr />
                    </div>

                   <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-8 col-md-auto">
                          Payment is pending for the order
                    </div>                     
                    <div className="col-1 col-md-auto ml-auto">
                      {this.state.showHideToggle4 &&                 
                        <div >
                          <span className="material-icons" style={{ cursor: "pointer" }} onClick={this.toggle4}>
                            toggle_on
                          </span>
                        </div> 
                      }
                      {!this.state.showHideToggle4 &&                 
                        <div>
                          <span className="material-icons" style={{ cursor: "pointer" }} onClick={this.toggle4}>
                            toggle_off
                          </span>
                        </div> 
                      }
                    </div>      
                      </div>
                      <hr />
                    </div>
                 
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-8 col-md-auto">
                          Task Created Successfully by Customer
                    </div>                     
                    <div className="col-1 col-md-auto ml-auto">
                      {this.state.showHideToggle5 &&                 
                        <div >
                          <span className="material-icons" style={{ cursor: "pointer" }} onClick={this.toggle5}>
                            toggle_on
                          </span>
                        </div> 
                      }
                      {!this.state.showHideToggle5 &&                 
                        <div>
                          <span className="material-icons" style={{ cursor: "pointer" }} onClick={this.toggle5}>
                            toggle_off
                          </span>
                        </div> 
                      }
                    </div>    
                      </div>
                      <hr />
                    </div>

                   <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-8 col-md-auto">
                          Payment is pending for the order
                    </div>                     
                    <div className="col-1 col-md-auto ml-auto">
                      {this.state.showHideToggle6 &&                 
                        <div >
                          <span className="material-icons" style={{ cursor: "pointer" }}
                           onClick={this.toggle6}>
                            toggle_on
                          </span>
                        </div> 
                      }
                      {!this.state.showHideToggle6 &&                 
                        <div>
                          <span className="material-icons" style={{ cursor: "pointer" }} 
                          onClick={this.toggle6}>
                            toggle_off
                          </span>
                        </div> 
                      }
                    </div>   
                      </div>
                      <hr />
                    </div>
                 
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-8 col-md-auto">
                          Task Created Successfully by Customer
                    </div>                     
                    <div className="col-1 col-md-auto ml-auto">
                      {this.state.showHideToggle7 &&                 
                        <div >
                          <span className="material-icons" style={{ cursor: "pointer" }} onClick={this.toggle7}>
                            toggle_on
                          </span>
                        </div> 
                      }
                      {!this.state.showHideToggle7 &&                 
                        <div>
                          <span className="material-icons" style={{ cursor: "pointer" }} onClick={this.toggle7}>
                            toggle_off
                          </span>
                        </div> 
                      }
                    </div>    
                      </div>
                      <hr />
                    </div>

                   <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-8 col-md-auto">
                          Payment is pending for the order
                    </div>                     
                    <div className="col-1 col-md-auto ml-auto">
                      {this.state.showHideToggle8 &&                 
                        <div >
                          <span className="material-icons" style={{ cursor: "pointer" }} onClick={this.toggle8}>
                            toggle_on
                          </span>
                        </div> 
                      }
                      {!this.state.showHideToggle8 &&                 
                        <div>
                          <span className="material-icons" style={{ cursor: "pointer" }} onClick={this.toggle8}>
                            toggle_off
                          </span>
                        </div> 
                      }
                    </div>     
                      </div>
                      <hr />
                    </div>
                 
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-8 col-md-auto">
                          Task Created Successfully by Customer
                    </div>                     
                    <div className="col-1 col-md-auto ml-auto">
                      {this.state.showHideToggle9 &&                 
                        <div >
                          <span className="material-icons" style={{ cursor: "pointer" }} onClick={this.toggle9}>
                            toggle_on
                          </span>
                        </div> 
                      }
                      {!this.state.showHideToggle9 &&                 
                        <div>
                          <span className="material-icons" style={{ cursor: "pointer" }} onClick={this.toggle9}>
                            toggle_off
                          </span>
                        </div> 
                      }
                    </div>      
                      </div>
                      <hr />
                    </div>

                   <div className='col-md-12'>10
                      <div className='row'>
                        <div className="col-8 col-md-auto">
                          Payment is pending for the order
                    </div>                     
                    <div className="col-1 col-md-auto ml-auto">
                      {this.state.showHideToggle10 &&                 
                        <div >
                          <span className="material-icons" style={{ cursor: "pointer" }} onClick={this.toggle10}>
                            toggle_on
                          </span>
                        </div> 
                      }
                      {!this.state.showHideToggle10 &&                 
                        <div>
                          <span className="material-icons" style={{ cursor: "pointer" }} onClick={this.toggle10}>
                            toggle_off
                          </span>
                        </div> 
                      }
                    </div>    
                      </div>
                    </div>                 
                  </div>
                </div>   
                  </div>
                </div>

               
                  </div>
            
            {/* <div className="col-12 col-md-5">
              <div className="row">
                <div className='col-12 col-md-12 site-setting'>
                <div className="row">
                    <div className="col-1 col-md-auto">
                      <b>Site Setting</b>
                    </div>
                    <div className="col-1 col-md-auto ml-auto">
                      <span className="material-icons">
                      edit_note
                    </span>
                    </div>                   
                  </div>
                </div>
              </div>

            </div> */}


            <div className='col-12 col-md-4 side-content-legal'>
              <div className='row'>
                <div className="col-12 col-md-12 mt-2">
                  <div className="row">
                    <div className="col-12 col-md-12 help">
                      <div className="row">
                        <div className="col-12 col-md-auto">
                          <b>Help that you might need</b>
                        </div>                       
                      </div>
                    </div>
                    <div className="col-12 col-md-12 legal-content">
                      
                      <div className="row">

                        <div className="col-md-12">
                          <b>Default Dashboard</b>
                        </div>
                        <div className="col-md-12 ">
                        This type is used to determine
                         the customer’s ability to pay and find out
                       if there are enough funds on their credit card.
                       The actual fund transfer doesn’t take place in this case.
                         </div>

                        <div className="col-md-12 mt-2 ">
                        It makes sense to use the authorisation transaction type if
                       it takes some time for you to ship the products ordered online
                        and you need to guarantee the funding by the card issuer.
                         </div>

                         <div className="col-md-12 mt-2">
                          <b>Date Format</b>
                        </div>
                        <div className="col-md-12 ">
                        Capture transaction lets you capture the money that was previously
                            authorised and send it for settlement. Thus, if you sold
                                 a product online that took time to manufacture/prepare for 
                         shipping, you first need to authorize the payment, and when the product has been shipped 
                        – capture the amount, and it will be transferred to your account. 
         
                         </div>

                         <div className="col-md-12 mt-2">
                          <b>Time Format</b>
                        </div>
                        <div className="col-md-12 ">
                        Sale transaction combines authorisation and capture.
                             If you fulfil orders immediately that’s the transaction type you should use 
                         – the money is charged and transferred at once. It will also be suitable
                       if you sell a service membership and immediately provide the user with
                          access.
                         </div>

                         <div className="col-md-12 mt-2">
                          <b>Distance and Time Unit</b>
                        </div>
                        <div className="col-md-12 ">
                        Things happen, and if an order has to
                          be cancelled for some reason, the merchant will need to refund a
                        transaction and submit it for processing. Most of the time, 
                         a refund is limited to the original amount.
                         </div>
                         
                         {/* <div className="col-md-12 mt-2">
                          <b>Default Dashboard</b>
                        </div>
                        <div className="col-md-12 ">
                        This type is used to determine
                         the customer’s ability to pay and find out
                       if there are enough funds on their credit card.
                       The actual fund transfer doesn’t take place in this case.
                         </div>

                        <div className="col-md-12 mt-2 ">
                        It makes sense to use the authorisation transaction type if
                       it takes some time for you to ship the products ordered online
                        and you need to guarantee the funding by the card issuer.
                         </div>

                         <div className="col-md-12 mt-2">
                          <b>Date Format</b>
                        </div>
                        <div className="col-md-12 ">
                        Capture transaction lets you capture the money that was previously
                            authorised and send it for settlement. Thus, if you sold
                                 a product online that took time to manufacture/prepare for 
                         shipping, you first need to authorize the payment, and when the product has been shipped 
                        – capture the amount, and it will be transferred to your account. 
         
                         </div>

                         <div className="col-md-12 mt-2">
                          <b>Time Format</b>
                        </div>
                        <div className="col-md-12 ">
                        Sale transaction combines authorisation and capture.
                             If you fulfil orders immediately that’s the transaction type you should use 
                         – the money is charged and transferred at once. It will also be suitable
                       if you sell a service membership and immediately provide the user with
                          access.
                         </div>

                         <div className="col-md-12 mt-2">
                          <b>Distance and Time Unit</b>
                        </div>
                        <div className="col-md-12 ">
                        Things happen, and if an order has to
                          be cancelled for some reason, the merchant will need to refund a
                        transaction and submit it for processing. Most of the time, 
                         a refund is limited to the original amount.
                         </div>
                      */}
                      </div>


                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>

    )
  }
}
