import React, { Component } from 'react';
import './settingsIntegration.scss'

export default class SettingsIntegration extends Component {
  constructor(props) {
    super(props)
    this.state = {
    }
  }

  render() {
    return (
      <div className="integration-body">
        <div className="container-fluid">
          <div className="row">
            <div className="col-12 col-sm-6 col-md-4">
              <div className="row">
                <div className="col-12 col-md-12 int-heading">
                  <div className="row">
                    <div className="col-1 col-md-auto">
                      <b>Integration</b>
                    </div>
                    <div className="col-2 col-md-auto ml-auto">
                      <span className="material-icons">
                        edit_note
                    </span>
                    </div>
                  </div>
                </div>
                <div className="col-12 col-md-12 int-content1">
                  <div className="row">
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-8 col-md-auto">
                          Payment Gateway Provider
                    </div>
                        <div className="col-3 col-md-auto ml-auto">
                          Stripe
                    </div>
                      </div>
                      <hr />
                    </div>
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-4 col-md-auto">
                          Public Key
                    </div>
                        <div className="col-8 col-md-auto ml-auto">
                          **************************
                    </div>
                      </div>
                      <hr />
                    </div>
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-4 col-md-auto">
                          Private Key
                    </div>
                        <div className="col-8 col-md-auto ml-auto">
                          ***********************
                    </div>
                      </div>
                      <hr />
                    </div>
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-1 col-md-auto">
                          Email
                    </div>
                        <div className="col-7 col-md-auto ml-auto">
                          support@appsrhino.com
                    </div>
                      </div>
                      <hr />
                    </div>
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-1 col-md-auto">
                          Phone
                    </div>
                        <div className="col-6 col-md-auto ml-auto">
                          +91 9935468776
                    </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="col-12 col-md-12 mt-2 int-content">
                  <div className="row">
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-6 col-md-auto">
                          Sms Provider
                    </div>
                        <div className="col-3 col-md-auto ml-auto">
                          Twillio
                    </div>
                      </div>
                      <hr />
                    </div>
                    <div className='col-md-12'>
                      <div className='row'>
                      <div className="col-4 col-md-auto">
                          Public Key
                    </div>
                        <div className="col-8 col-md-auto ml-auto">
                          **************************
                    </div>
                      </div>
                      <hr />
                    </div>
                    <div className='col-md-12'>
                      <div className='row'>
                      <div className="col-4 col-md-auto">
                          Private Key
                    </div>
                        <div className="col-8 col-md-auto ml-auto">
                          ***********************
                    </div>
                      </div>
                      <hr />
                    </div>
                    <div className='col-md-12'>
                      <div className='row'>
                      <div className="col-1 col-md-auto">
                          Email
                    </div>
                        <div className="col-7 col-md-auto ml-auto">
                          support@appsrhino.com
                    </div>
                      </div>
                      <hr />
                    </div>
                    <div className='col-md-12'>
                      <div className='row'>
                      <div className="col-1 col-md-auto">
                          Phone
                    </div>
                        <div className="col-6 col-md-auto ml-auto">
                          +91 9935468776
                    </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="col-12 col-md-12 mt-2 int-content">
                  <div className="row">
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-1 col-md-auto">
                          Notifications
                    </div>
                        <div className="col-4 col-md-auto ml-auto">
                          Send Grid
                    </div>
                      </div>
                      <hr />
                    </div>
                    <div className='col-md-12'>
                      <div className='row'>
                      <div className="col-4 col-md-auto">
                          Public Key
                    </div>
                        <div className="col-8 col-md-auto ml-auto">
                          **************************
                    </div>
                      </div>
                      <hr />
                    </div>
                    <div className='col-md-12'>
                      <div className='row'>
                      <div className="col-4 col-md-auto">
                          Private Key
                    </div>
                        <div className="col-8 col-md-auto ml-auto">
                          ***********************
                    </div>
                      </div>
                      <hr />
                    </div>
                    <div className='col-md-12'>
                      <div className='row'>
                      <div className="col-1 col-md-auto">
                          Email
                    </div>
                        <div className="col-7 col-md-auto ml-auto">
                          support@appsrhino.com
                    </div>
                      </div>
                      <hr />
                    </div>
                    <div className='col-md-12'>
                      <div className='row'>
                      <div className="col-1 col-md-auto">
                          Phone
                    </div>
                        <div className="col-6 col-md-auto ml-auto">
                          +91 9935468776
                    </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className='col-12 col-md-4 center-div-int-email'>
              <div className='row'>
                <div className="col-12 col-md-12 int-content">
                  <div className="row">
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-6 col-md-auto">
                          Email Provider
                    </div>
                        <div className="col-4 col-md-auto ml-auto">
                          Send Grid
                    </div>
                      </div>
                      <hr />
                    </div>
                    <div className='col-md-12'>
                      <div className='row'>
                      <div className="col-4 col-md-auto">
                          Public Key
                    </div>
                        <div className="col-8 col-md-auto ml-auto">
                          **************************
                    </div>
                      </div>
                      <hr />
                    </div>
                    <div className='col-md-12'>
                      <div className='row'>
                      <div className="col-4 col-md-auto">
                          Private Key
                    </div>
                        <div className="col-8 col-md-auto ml-auto">
                          ***********************
                    </div>
                      </div>
                      <hr />
                    </div>
                    <div className='col-md-12'>
                      <div className='row'>
                      <div className="col-1 col-md-auto">
                          Email
                    </div>
                        <div className="col-7 col-md-auto ml-auto">
                          support@appsrhino.com
                    </div>
                      </div>
                      <hr />
                    </div>
                    <div className='col-md-12'>
                      <div className='row'>
                      <div className="col-1 col-md-auto">
                          Phone
                    </div>
                        <div className="col-6 col-md-auto ml-auto">
                          +91 9935468776
                    </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="col-12 col-md-12 mt-2 int-content">
                  <div className="row">
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-6 col-md-auto">
                          Google Maps API
                    </div>
                        <div className="col-3 col-md-auto ml-auto">
                          Google
                    </div>
                      </div>
                      <hr />
                    </div>
                    <div className='col-md-12'>
                      <div className='row'>
                      <div className="col-4 col-md-auto">
                          Public Key
                    </div>
                        <div className="col-8 col-md-auto ml-auto">
                          **************************
                    </div>
                      </div>
                      <hr />
                    </div>
                    <div className='col-md-12'>
                      <div className='row'>
                      <div className="col-4 col-md-auto">
                          Private Key
                    </div>
                        <div className="col-8 col-md-auto ml-auto">
                          ***********************
                    </div>
                      </div>
                      <hr />
                    </div>
                    <div className='col-md-12'>
                      <div className='row'>
                      <div className="col-1 col-md-auto">
                          Email
                    </div>
                        <div className="col-7 col-md-auto ml-auto">
                          support@appsrhino.com
                    </div>
                      </div>
                      <hr />
                    </div>
                    <div className='col-md-12'>
                      <div className='row'>
                      <div className="col-1 col-md-auto">
                          Phone
                    </div>
                        <div className="col-6 col-md-auto ml-auto">
                          +91 9935468776
                    </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="col-12 col-md-12 mt-2 int-heading2">
                  <div className="row">
                    <div className="col-1 col-md-auto">
                      <b>Status</b>
                    </div>
                  </div>
                </div>
                <div className="col-12 col-md-12 int-content1">
                  <div className="row">
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-6 col-md-auto">
                          Payment Gateway
                    </div>
                        <div className="col-2 col-md-auto ml-auto">
                          Active
                    </div>
                      </div>
                      <hr />
                    </div>
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-6 col-md-auto">
                          SMS Gateway
                    </div>
                        <div className="col-2 col-md-auto ml-auto">
                          Active
                    </div>
                      </div>
                      <hr />
                    </div>
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-6 col-md-auto">
                          Notifications
                    </div>
                        <div className="col-2 col-md-auto ml-auto">
                          Active
                    </div>
                      </div>
                      <hr />
                    </div>
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-1 col-md-auto">
                          Email
                    </div>
                        <div className="col-2 col-md-auto ml-auto">
                          Active
                    </div>
                      </div>
                      <hr />
                    </div>
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-4 col-md-auto">
                          Google Maps
                    </div>
                        <div className="col-2 col-md-auto ml-auto">
                          Active
                    </div>
                      </div>
                    </div>
                  </div>
                </div>



              </div>
            </div>

            <div className='col-12 col-md-4 side-content-int'>
              <div className='row'>
                <div className="col-12 col-md-12">
                  <div className="row">
                    <div className="col-12 col-md-12 sidebar-steps-div">
                      <div className="row">
                        <div className="col-12 col-md-auto">
                          <b>How to integrate Payment Gateway?</b>
                        </div>
                      </div>
                    </div>
                    <div className="col-12 col-md-12 int-side-content">
                      <div className="row">

                        <div className="col-md-12 mt-4">
                          <b>Step- 1</b>
                        </div>
                        <div className="col-md-12 ">
                          This type is used to determine the customer’s ability to pay and
                          find out if there are enough funds on their credit card.
                          The actual fund transfer doesn’t take place in this case.
                        </div>
                        <div className="col-md-12 mt-2">
                          It makes sense to use the authorisation transaction type
                          if it takes some time for you to ship the products ordered
                          online and you need to guarantee the funding by the card issuer.
                        </div>

                        <div className="col-md-12 mt-2">
                          <b>Step- 2</b>
                        </div>
                        <div className="col-md-12 ">
                          Capture transaction lets you capture the money that was previously
                          authorised and send it for settlement. Thus, if you sold a product
                          online that took time to manufacture/prepare for shipping, you first
                          need to authorize the payment, and when the product has been shipped
                          – capture the amount, and it will be transferred to your account.
                         </div>

                        <div className="col-md-12 mt-2">
                          <b>Step- 3</b>
                        </div>
                        <div className="col-md-12 ">
                          Sale transaction combines
                          authorisation and capture. If you fulfil orders
                          immediately that’s the transaction type you should use
                          – the money is charged and transferred at once.
                          It will also be suitable if you sell a service membership
                          and immediately provide the user with access.
                         </div>

                        <div className="col-md-12 mt-2">
                          <b>Step- 4</b>
                        </div>
                        <div className="col-md-12 ">
                          Things happen, and if an
                          order has to be cancelled for some
                          reason, the merchant will need to refund
                          a transaction and submit it for processing.
                          Most of the time, a refund is limited to the original amount
                         </div>

                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>


          </div>
        </div>
      </div>

    )
  }
}
