import React, { Component } from 'react';
import './settingsPayment.scss'
import AddDetailsAlertPayment from './addDetailsAlertPayment';
import DeleteAlert from '../../deleteAlert';

export default class SettingsPayment extends Component {
  constructor(props) {
    super(props)
    this.state = {
      openAdd: false,
      openDelete: false,
    }
  }

  delete(e) {
    this.setState({
      openDelete: true
    })
  }

  handleDelete = () => {
    this.setState({
      openDelete: false
    })
  }

  add(e) {
    this.setState({
      openAdd: true
    })
  }
  handleClose = () => {
    this.setState({
      openAdd: false
    })
  }
  render() {
    return (
      <div className="payment-settings-body">
        <div className="container-fluid">
          <div className="row">
            <div className="col-12 col-md-3">
              <div className="row">
                <div className="col-12 col-md-12 pay-heading">
                  <div className="row">
                    <div className="col-1 col-md-auto">
                      <b>Payments</b>
                    </div>
                    <div className="col-2 col-md-auto ml-auto">
                      <span className="material-icons">
                        edit_note
                    </span>
                    </div>
                  </div>
                </div>
                <div className="col-12 col-md-12 pay-content1">
                  <div className="row">
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-1 col-md-auto">Currency</div>
                        <div className="col-2 col-md-auto ml-auto">USD</div>
                      </div>
                      <hr />
                    </div>
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-6 col-md-auto">Default Delivery Fee</div>
                        <div className="col-3 col-md-auto ml-auto">10 USD</div>
                      </div>
                      <hr />
                    </div>
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-9 col-md-auto">Default Tax Rate</div>
                        <div className="col-3 col-md-auto ml-auto">18 %</div>
                      </div>
                      <hr />
                    </div>
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-8 col-md-auto">Admin Comission</div>
                        <div className="col-3 col-md-auto ml-auto">1 %</div>
                      </div>
                      <hr />
                    </div>
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-7 col-md-auto">Payment Routing</div>
                        <div className="col-4 col-md-auto ml-auto">All to admin</div>
                      </div>
                    </div>
                  </div>

                </div>

                <div className="col-12 col-md-12 mt-2 pay-heading2">
                  <div className="row">
                    <div className="col-8 col-md-auto">
                      <b>My Cards</b>
                    </div>
                    <div className="col-2 col-md-auto ml-auto">
                      <span className="material-icons" onClick={this.add.bind(this)} style={{ cursor: "pointer" }}>
                        add_circle_outline
                    </span>
                    <AddDetailsAlertPayment open={this.state.openAdd} close={this.handleClose} />
                    </div>
                  </div>
                </div>

                <div className="col-12 col-md-12 mt-2 pay-content2">
                  <div className="row">
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-8 col-md-auto">
                          Sam Curran
                        </div>
                        <div className="col-2 col-md-auto ml-auto">
                          <span className="material-icons">
                            edit_note
                          </span>
                        </div>
                        <div className="col-2 col-md-auto">
                          <span className="material-icons" onClick={this.delete.bind(this)} style={{ cursor: "pointer" }}>
                            delete
                          </span>
                          <DeleteAlert open={this.state.openDelete} close={this.handleDelete} />
                        </div>
                      </div>
                      <hr />
                    </div>
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-12 col-md-auto">
                          4567 7788 0098 6501
                    </div>
                      </div>
                      <hr />
                    </div>
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-6 col-md-auto">
                          Default Tax Rate
                    </div>
                        <div className="col-3 col-md-auto ml-auto">
                          18 %
                    </div>
                      </div>
                      <hr />
                    </div>
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-5 col-md-6">
                          08 / 27
                        </div>
                        <div className='col-1 col-md-1 vr'></div>
                        <div className="col-5 col-md-4">
                          340
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="col-12 col-md-12 mt-2 pay-content2">
                <div className="row">
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-8 col-md-auto">
                          Sam Curran
                        </div>
                        <div className="col-2 col-md-auto ml-auto">
                          <span className="material-icons">
                            edit_note
                          </span>
                        </div>
                        <div className="col-2 col-md-auto">
                          <span className="material-icons" onClick={this.delete.bind(this)} style={{ cursor: "pointer" }}>
                            delete
                          </span>
                        </div>
                      </div>
                      <hr />
                    </div>
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-12 col-md-auto">
                          4567 7788 0098 6501
                    </div>
                      </div>
                      <hr />
                    </div>
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-6 col-md-auto">
                          Default Tax Rate
                    </div>
                        <div className="col-3 col-md-auto ml-auto">
                          18 %
                    </div>
                      </div>
                      <hr />
                    </div>
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-5 col-md-6">
                          08 / 27
                        </div>
                        <div className='col-1 col-md-1 vr'></div>
                        <div className="col-5 col-md-4">
                          340
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="col-12 col-md-12 mt-2 pay-content2">
                <div className="row">
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-8 col-md-auto">
                          Sam Curran
                        </div>
                        <div className="col-2 col-md-auto ml-auto">
                          <span className="material-icons">
                            edit_note
                          </span>
                        </div>
                        <div className="col-2 col-md-auto">
                          <span className="material-icons" onClick={this.delete.bind(this)} style={{ cursor: "pointer" }}>
                            delete
                          </span>
                        </div>
                      </div>
                      <hr />
                    </div>
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-12 col-md-auto">
                          4567 7788 0098 6501
                    </div>
                      </div>
                      <hr />
                    </div>
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-6 col-md-auto">
                          Default Tax Rate
                    </div>
                        <div className="col-3 col-md-auto ml-auto">
                          18 %
                    </div>
                      </div>
                      <hr />
                    </div>
                    <div className='col-md-12'>
                      <div className='row'>
                        <div className="col-5 col-md-6">
                          08 / 27
                        </div>
                        <div className='col-1 col-md-1 vr'></div>
                        <div className="col-5 col-md-4">
                          340
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

              </div>
            </div>

            <div className="col-12 col-md-5 center-payment-div">
              <div className="row">
                <div className="col-12 col-md-12 pay-heading">
                  <div className="row">
                    <div className="col-6 col-md-auto">
                      <b>Invoice Templates</b>
                    </div>
                    <div className="col-5 col-md-auto ml-auto">
                      Save as Default
                    </div>
                  </div>
                </div>

                <div className="col-12 col-md-12 pay-center-content">
                  <div className="row">
                    <div className="col-1 col-md-auto arrow-center-pay">
                      <span className="material-icons">
                        chevron_left
                    </span>
                    </div>

                    <div className="col-9 col-md-9 center-box-pay">
                      <div className="row">

                        <div className="col-12 col-md-12">
                          <div className='row'>
                            <div className='col-2 col-md-2 offset-9 mt-2 center-check'>
                              <span className="material-icons">
                                check
                              </span>
                            </div>
                          </div>
                        </div>

                        <div className="col-12 col-md-12">
                          <div className='row'>
                            <div className='col-2 col-md-2 offset-2 center-person'>
                              <span className="material-icons">
                                person
                              </span>
                            </div>
                            <div className='col-8 col-md-3 offset-1 mt-6 center-line-pay'>
                              <div className='row'>
                                <div className='col-10 col-md-10 offset-1 mt-6 hr'>
                                </div>
                                <div className='col-12 col-md-12 mt-2 hr2'>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>

                        <div className="col-12 col-md-12 mt-6">
                          <div className='row'>
                            <div className='col-8 col-md-6 offset-3'>
                              <div className='row'>
                                {/* <div className='col-12 col-md-12'>
                                  <div className='row'>
                                    <div className='col-1 col-md-1 pt'>
                                    </div>
                                    <div className='col-8 col-md-8 offset-1 pt2'>
                                    </div>
                                  </div>
                                </div> */}

                                {/* <div className='col-12 col-md-12 mt-6'>
                                  <div className='row'>
                                    <div className='col-1 col-md-1 pt'>
                                    </div>
                                    <div className='col-8 col-md-8 offset-1 pt2'>
                                    </div>
                                  </div>
                                </div> */}

                                {/* <div className='col-12 col-md-12'>
                                  <div className='row'>
                                    <div className='col-1 col-md-1 pt'>
                                    </div>
                                    <div className='col-8 col-md-8 offset-1 pt2'>
                                    </div>
                                  </div>
                                </div> */}

                                {/* <div className='col-12 col-md-12'>
                                  <div className='row'>
                                    <div className='col-1 col-md-1 pt'>
                                    </div>
                                    <div className='col-8 col-md-8 offset-1 pt2'>
                                    </div>
                                  </div>
                                </div> */}

                                {/* <div className='col-12 col-md-12'>
                                  <div className='row'>
                                    <div className='col-1 col-md-1 pt'>
                                    </div>
                                    <div className='col-8 col-md-8 offset-1 pt2'>
                                    </div>
                                  </div>
                                </div> */}

                              </div>
                            </div>
                          </div>
                        </div>


                      </div>
                    </div>

                    <div className="col-1 col-md-auto arrow-center-pay">
                      <span className="material-icons">
                        chevron_right
                    </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className='col-12 col-md-4 side-content-pay'>
              <div className='row'>
                <div className="col-12 col-md-12">
                  <div className="row">
                    <div className="col-12 col-md-12 sidebar-steps-div-pay">
                      <div className="row">
                        <div className="col-12 col-md-auto">
                          <b>How to integrate Payment Gateway?</b>
                        </div>
                      </div>
                    </div>
                    <div className="col-12 col-md-12 pay-side-content">
                      <div className="row">

                        <div className="col-md-12 mt-4">
                          <b>Step- 1</b>
                        </div>
                        <div className="col-md-12 ">
                          This type is used to determine the customer’s ability to pay and
                          find out if there are enough funds on their credit card.
                          The actual fund transfer doesn’t take place in this case.
                        </div>
                        <div className="col-md-12 mt-2">
                          It makes sense to use the authorisation transaction type
                          if it takes some time for you to ship the products ordered
                          online and you need to guarantee the funding by the card issuer.
                        </div>

                        <div className="col-md-12 mt-2">
                          <b>Step- 2</b>
                        </div>
                        <div className="col-md-12 ">
                          Capture transaction lets you capture the money that was previously
                          authorised and send it for settlement. Thus, if you sold a product
                          online that took time to manufacture/prepare for shipping, you first
                          need to authorize the payment, and when the product has been shipped
                          – capture the amount, and it will be transferred to your account.
                         </div>

                        <div className="col-md-12 mt-2">
                          <b>Step- 3</b>
                        </div>
                        <div className="col-md-12 ">
                          Sale transaction combines
                          authorisation and capture. If you fulfil orders
                          immediately that’s the transaction type you should use
                          – the money is charged and transferred at once.
                          It will also be suitable if you sell a service membership
                          and immediately provide the user with access.
                         </div>

                        <div className="col-md-12 mt-2">
                          <b>Step- 4</b>
                        </div>
                        <div className="col-md-12 ">
                          Things happen, and if an
                          order has to be cancelled for some
                          reason, the merchant will need to refund
                          a transaction and submit it for processing.
                          Most of the time, a refund is limited to the original amount
                         </div>

                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>

    )
  }
}
