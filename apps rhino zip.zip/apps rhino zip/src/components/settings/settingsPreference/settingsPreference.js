import React, { Component } from 'react';
import './settingsPreference.scss'

export default class SettingsPreference extends Component {
  constructor(props) {
    super(props)
    this.state = {

      userDetails: {},
      openDelete: false,
    }
  }

  delete(e) {
    this.setState({
      openDelete: true
    })
  }

  handleClose = () => {
    this.setState({
      openDelete: false
    })
  }

  render() {
    return (
      <div className="preference-body">
        <div className="container-fluid">
          <div className="row">
            <div className="col-12 col-md-8">
              <div className="row">
                <div className="col-12 col-md-12 mt-2 preference-heading">
                  <div className="row">
                    <div className="col-1 col-md-auto">
                    </div>
                    <div className="col-1 col-md-auto ml-auto mt-4">
                   
                <span className="material-icons" data-toggle="dropdown" style={{ cursor: "pointer" }}>
                  more_vert
                </span>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                  <a class="dropdown-item" href="#">More Actions</a>
                </div>
                    </div>

                  </div>
                </div>

                <div className="col-12 col-md-12 ">
                  <div className="row">
                    <div className="col-md-12 qna1">
                      <div className="row">
                        <div className="col-12 col-md-12 img-fluid">
                          <img src="alexandar-todov-AMzC2RVurO4-unsplash (2).png" className='img-style-pre' />
                        </div>
                        <div className="col-12 col-md-12" style={{ textAlign: "center" }}>
                          <b>Super Admin</b>
                        </div>
                        <div className="col-12 col-md-12 ">
                          <div className="row">
                            <div className="col-12 col-md-5 mt-4">
                              <div className='row'>
                                <div className="col-6 col-md-6">
                                  <b>Basic Details</b>
                                </div>
                                <div className="col-6 col-md-6" style={{ color: "#005FFF" }}>
                                  Edit
                                </div>
                                <div className="col-6 col-md-6">
                                  <b>Name :</b>
                                </div>
                                <div className="col-6 col-md-6">
                                  Peter Jose
                                </div>
                                <div className="col-6 col-md-6">
                                  <b>Primary Email :</b>
                                </div>
                                <div className="col-6 col-md-6">
                                  jose.peter@gmail.com
                                </div>
                                <div className="col-6 col-md-6">
                                  <b>Secondary Email :</b>
                                </div>
                                <div className="col-6 col-md-6">
                                  Peter198Jose@yahoo.com
                                </div>
                                <div className="col-6 col-md-6">
                                  <b>Mobile No. :</b>
                                </div>
                                <div className="col-6 col-md-6">
                                  +1 89787 00095
                                </div>
                                <div className="col-6 col-md-6">
                                  <b>Role :</b>
                                </div>
                                <div className="col-6 col-md-6">
                                  Super Admin
                                </div>
                                <div className="col-6 col-md-6">
                                  <b>Billing Address :</b>
                                </div>
                                <div className="col-6 col-md-6">
                                  23 A, New Street, Near Big Café, California, USA ZIP 980010
                                </div>
                              </div>
                            </div>

                            <div className="col-12 col-md-6 offset-1 mt-4">
                              <div className='row'>
                                <div className="col-6 col-md-6">
                                  <b>Preferences</b>
                                </div>
                                <div className="col-6 col-md-6">
                                </div>
                                <div className="col-6 col-md-6">
                                  <b>Date Format :</b>
                                </div>
                                <div className="col-6 col-md-6">
                                  20 Sep 2020
                                </div>
                                <div className="col-6 col-md-6">
                                  <b>Time Format :</b>
                                </div>
                                <div className="col-6 col-md-6">
                                  11 : 39 PM
                                </div>
                                <div className="col-6 col-md-6">
                                  <b>Distance Unit :</b>
                                </div>
                                <div className="col-6 col-md-6">
                                  KM
                                </div>
                                <div className="col-6 col-md-6">
                                  <b>Choose your Theme:</b>
                                </div>
                                <div className="col-6 col-md-6">
                                </div>

                                <div className="col-12 col-md-12 mt-4 ">
                                  <div className="row">
                                    <div className="col-1 col-md-auto color-theme1">
                                    </div>
                                    <div className="col-1 col-md-auto ml-3 mt-4 color-theme2">
                                    </div>
                                    <div className="col-1 col-md-auto ml-3 mt-4 color-theme3">
                                    </div>
                                    <div className="col-1 col-md-auto ml-3 mt-4 color-theme4">
                                    </div>
                                    <div className="col-1 col-md-auto ml-3 mt-4 color-theme5">
                                    </div>
                                  </div>
                                </div>

                                <div className="col-12 col-md-12 ml-1 mt-2 ">
                                  <div className="row">
                                    <div className="col-1 col-md-auto ml-4 mt-4 color-theme6">
                                    </div>
                                    <div className="col-1 col-md-auto ml-3 mt-4 color-theme7">
                                    </div>
                                    <div className="col-1 col-md-auto ml-3 mt-4 color-theme8">
                                    </div>
                                    <div className="col-1 col-md-auto ml-3 mt-4 color-theme9">
                                    </div>
                                    <div className="col-1 col-md-auto ml-3 mt-4 color-theme10">
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                  </div>
                </div>

              </div>
            </div>

            <div className='col-12 col-md-4 side-content-preference'>
              <div className='row'>
                <div className="col-12 col-md-12 mt-2">
                  <div className="row">
                    <div className="col-12 col-md-12 help-pre">
                      <div className="row">
                        <div className="col-12 col-md-auto">
                          <b>Help that you might need</b>
                        </div>
                      </div>
                    </div>
                    <div className="col-12 col-md-12 pre-content">
                      <div className="row">

                        <div className="col-md-12">
                          <b>Default Dashboard</b>
                        </div>
                        <div className="col-md-12 ">
                          This type is used to determine
                          the customer’s ability to pay and find out
                          if there are enough funds on their credit card.
                          The actual fund transfer doesn’t take place in this case.
                           </div>

                        <div className="col-md-12 mt-2 ">
                          It makes sense to use the authorisation transaction type if
                          it takes some time for you to ship the products ordered online
                          and you need to guarantee the funding by the card issuer.
                          </div>

                        <div className="col-md-12 mt-2">
                          <b>Date Format</b>
                        </div>
                        <div className="col-md-12 ">
                          Capture transaction lets you capture the money that was previously
                          authorised and send it for settlement. Thus, if you sold
                          a product online that took time to manufacture/prepare for
                          shipping, you first need to authorize the payment, and when the product has been shipped
                          – capture the amount, and it will be transferred to your account.

                       </div>

                        <div className="col-md-12 mt-2">
                          <b>Time Format</b>
                        </div>
                        <div className="col-md-12 ">
                          Sale transaction combines authorisation and capture.
                          If you fulfil orders immediately that’s the transaction type you should use
                          – the money is charged and transferred at once. It will also be suitable
                          if you sell a service membership and immediately provide the user with
                          access.
                          </div>

                        <div className="col-md-12 mt-2">
                          <b>Distance and Time Unit</b>
                        </div>
                        <div className="col-md-12 ">
                          Things happen, and if an order has to
                          be cancelled for some reason, the merchant will need to refund a
                          transaction and submit it for processing. Most of the time,
                          a refund is limited to the original amount.
                            </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>


          </div>
        </div>
      </div>

    )
  }
}
