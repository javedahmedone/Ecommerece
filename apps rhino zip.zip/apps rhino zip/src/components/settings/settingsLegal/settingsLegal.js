import React, { Component } from 'react';
import './settingsLegal.scss'
import AddDetailsAlertLegal from './addDetailsAlertLegal';

export default class SettingsLegal extends Component {
  constructor(props) {
    super(props)
    this.state = {
      openAdd: false,
      userDetails: {},
    }
  }

  add(e) {
    this.setState({
      openAdd: true
    })
  }
  handleClose = () => {
    this.setState({
      openAdd: false
    })
  }
  render() {
    return (
      <div className="legal-body">
        <div className="container-fluid">
          <div className="row">
            <div className="col-12 col-md-8">
              <div className="row">
                <div className="col-12 col-md-12 legal-heading">
                  <div className="row">
                    <div className="col-5 col-md-auto">
                      <b>About Us</b>
                    </div>
                    <div className="col-2 col-md-auto ml-auto">
                      <span className="material-icons">
                        edit_note
                    </span>
                    </div>
                  </div>
                </div>
                <div className="col-12 col-md-12 legal-content">
                  <div className="row">
                    <div className="col-md-12">
                      <b>Updated On-</b> 21 Sep 2020 by Drinkyfy PVT LTD
                        <hr />
                    </div>
                    <div className="col-md-12">
                      <b>Users:</b>
                      
                    </div>
                    <div className="col-md-12 mt-2">
                    This type is used to determine the customer’s ability to pay
                     and find out if there are enough funds on their credit card. The actual fund transfer
                      doesn’t take place in this case This type is used to determine the customer’s ability
                       to pay and find out if there are enough funds on their credit card. The actual
                        fund transfer doesn’t take place in this case This type is used to determine
                         the customer’s ability to pay credit card. The actual fund transfer doesn’t 
                         take place in this case This type is used to determine the customer’s ability 
                         to pay and find out if there are enough 
                    funds on their credit card. The actual fund transfer doesn’t take place in this case.
                    </div>
                    <div className="col-md-12 mt-2">
                      <b>Commerce:</b>
                    </div>
                    <div className="col-md-12 mt-2 ">
                    This type is used to determine the customer’s ability to pay and 
                    find out if there are enough funds on their credit card. The actual 
                    fund transfer doesn’t take place in this case This type is used to determine
                     the customer’s ability to pay and find out if there are enough
                     funds on their credit card. The actual fund transfer doesn’t take place in this case.
                    </div>
                    <div className="col-md-12 mt-4 ">
                      <div className="row">
                        <div className="col-3 col-md-auto ml-auto">
                          <b>Cancel</b>
                        </div>
                        <div className="col-4 col-md-auto">
                          <input type="submit" className="legal-button" value="Update" />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>


              </div>
            </div>

            <div className='col-12 col-xs-12 col-md-4 side-content-legal'>
              <div className='row'>

                <div className="col-12 col-md-12">
                  <div className="row">
                    <div className="col-12 col-md-12 legal-side-heading1">
                      <div className="row">
                        <div className="col-9 col-md-auto">
                          <b>Terms & Conditions</b>
                        </div>
                        <div className="col-1 col-md-auto ml-auto">
                          <span className="material-icons">
                            fullscreen
                          </span>
                        </div>
                        <div className="col-1 col-md-auto">
                          <span className="material-icons">
                            edit_note
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="col-12 col-md-12 legal-content">
                      <div className="row">

                        <div className="col-12 col-md-12">
                          <b>Default Dashboard</b>
                        </div>
                        <div className="col-12 col-md-12 ">
                        This type is used to determine the customer’s ability to pay and
                         find out if there are enough funds on their 
                        credit card. The actual fund transfer doesn’t take place in this case.
                        </div>


                      </div>
                    </div>
                  </div>
                </div>

                <div className="col-12 col-md-12 mt-2">
                  <div className="row">
                    <div className="col-12 col-md-12 legal-side-heading2">
                      <div className="row">
                        <div className="col-8 col-md-auto">
                          <b>Cancellation Policy</b>
                        </div>
                        <div className="col-1 col-md-auto ml-auto">
                          <span className="material-icons">
                            fullscreen
                          </span>
                        </div>
                        <div className="col-1 col-md-auto">
                          <span className="material-icons">
                            edit_note
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="col-12 col-md-12 legal-content">
                      <div className="row">

                        <div className="col-md-12 ">
                        This type is used to determine the customer’s ability to pay and
                         find out if there are enough funds on their 
                        credit card. The actual fund transfer doesn’t take place in this case.
                    </div>

                      </div>
                    </div>
                  </div>
                </div>

                <div className="col-12 col-md-12 mt-2">
                  <div className="row">
                    <div className="col-12 col-md-12 legal-side-heading3">
                      <div className="row">
                        <div className="col-6 col-md-auto">
                          <b>Privacy Policy</b>
                        </div>
                        <div className="col-1 col-md-auto ml-auto">
                          <span className="material-icons">
                            fullscreen
                          </span>
                        </div>
                        <div className="col-1 col-md-auto">
                          <span className="material-icons">
                            edit_note
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="col-12 col-md-12 legal-content">
                      <div className="row">

                        <div className="col-md-12">
                          <b>Time Format</b>
                        </div>
                        <div className="col-md-12 ">
                        This type is used to determine the customer’s ability to pay and
                         find out if there are enough funds on their 
                        credit card. The actual fund transfer doesn’t take place in this case.
                         </div>

                      </div>
                    </div>
                  </div>
                </div>

              </div>
            </div>

            <div className="col-12 col-md-8">
              <div className="row">
                <div className="col-12 col-md-12 mt-2 legal-heading2">
                  <div className="row">
                    <div className="col-1 col-md-auto">
                      <b>F&Qs</b>
                    </div>
                    <div className="col-1 col-md-auto ml-auto">
                      <span className="material-icons" onClick={this.add.bind(this)} style={{ cursor: "pointer" }}>
                        add_circle_outline
                    </span>
                    <AddDetailsAlertLegal open={this.state.openAdd} close={this.handleClose} />
                    </div>
                    <div className="col-1 col-md-auto">
                <span className="material-icons" data-toggle="dropdown" style={{ cursor: "pointer" }}>
                  more_vert
                </span>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                  <a class="dropdown-item" href="#">More Actions</a>
                </div>
              </div>
                  </div>
                </div>
                <div className="col-12 col-md-12 ">
                  <div className="row">
                    <div className="col-md-12 qna1">
                      <div className="row">
                        <div className="col-md-12">
                          <b>How to complete setup?</b>
                        </div>
                        <div className="col-md-12 mt-2 ">
                        It makes sense to use the authorisation transaction type if it takes 
                        some time for you to ship the products ordered online and you need to Date
                         Format Capture transaction lets you capture the money that was previously authorised 
                        and send it for settlement. Thus, if you sold a product online that took time.
                    </div>
                      </div>
                    </div>

                    <div className="col-md-12 mt-2 qna">
                      <div className="row">
                        <div className="col-md-12">
                          <b>How to complete setup?</b>
                        </div>
                        <div className="col-md-12 mt-2">
                        It makes sense to use the authorisation transaction type if it takes 
                        some time for you to ship the products ordered online and you need to Date
                         Format Capture transaction lets you capture the money that was previously authorised 
                        and send it for settlement. Thus, if you sold a product online that took time.
                    </div>
                      </div>
                    </div>

                    <div className="col-md-12 mt-2 qna">
                      <div className="row">
                        <div className="col-md-12">
                          <b>How to complete setup?</b>
                        </div>
                        <div className="col-md-12 mt-2">
                        It makes sense to use the authorisation transaction type if it takes 
                        some time for you to ship the products ordered online and you need to Date
                         Format Capture transaction lets you capture the money that was previously authorised 
                        and send it for settlement. Thus, if you sold a product online that took time.
                    </div>
                      </div>
                    </div>

                  </div>
                </div>

              </div>
            </div>

            <div className='col-12 col-md-4 side-content-legal'>
              <div className='row'>
                <div className="col-12 col-md-12 mt-2">
                  <div className="row">
                    <div className="col-12 col-md-12 help">
                      <div className="row">
                        <div className="col-12 col-md-auto">
                          <b>Help that you might need</b>
                        </div>                       
                      </div>
                    </div>
                    <div className="col-12 col-md-12 legal-content">
                      
                      <div className="row">

                        <div className="col-md-12">
                          <b>Default Dashboard</b>
                        </div>
                        <div className="col-md-12 ">
                        This type is used to determine
                         the customer’s ability to pay and find out
                       if there are enough funds on their credit card.
                       The actual fund transfer doesn’t take place in this case.
                         </div>

                        <div className="col-md-12 mt-2 ">
                        It makes sense to use the authorisation transaction type if
                       it takes some time for you to ship the products ordered online
                        and you need to guarantee the funding by the card issuer.
                         </div>

                         <div className="col-md-12 mt-2">
                          <b>Date Format</b>
                        </div>
                        <div className="col-md-12 ">
                        Capture transaction lets you capture the money that was previously
                            authorised and send it for settlement. Thus, if you sold
                                 a product online that took time to manufacture/prepare for 
                         shipping, you first need to authorize the payment, and when the product has been shipped 
                        – capture the amount, and it will be transferred to your account. 
         
                         </div>

                         <div className="col-md-12 mt-2">
                          <b>Time Format</b>
                        </div>
                        <div className="col-md-12 ">
                        Sale transaction combines authorisation and capture.
                             If you fulfil orders immediately that’s the transaction type you should use 
                         – the money is charged and transferred at once. It will also be suitable
                       if you sell a service membership and immediately provide the user with
                          access.
                         </div>

                         <div className="col-md-12 mt-2">
                          <b>Distance and Time Unit</b>
                        </div>
                        <div className="col-md-12 ">
                        Things happen, and if an order has to
                          be cancelled for some reason, the merchant will need to refund a
                        transaction and submit it for processing. Most of the time, 
                         a refund is limited to the original amount.
                         </div>
                      </div>


                    </div>
                  </div>
                </div>
              </div>
            </div>


          </div>
        </div>
      </div>

    )
  }
}
