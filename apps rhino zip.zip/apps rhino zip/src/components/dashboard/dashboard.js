import React, { Component } from 'react'
import './dashboard.scss'

export default class User extends Component {
  constructor(props) {
    super(props);
    this.state = {
      user: [
        {
          name: "Mr.Paige",
          order: "5545",
          location: "Suite 382, North Wills 60670-9001",
          price: "750",
          mobile: "9034342475",
          date: "08/15/2020",
          time: "9:08 AM"
        },
        {
          name: "Mr.Paige",
          order: "5545",
          location: "Suite 382, North Wills 60670-9001",
          price: "750",
          mobile: "9034342475",
          date: "08/15/2020",
          time: "9:08 AM"
        },
        {
          name: "Mr.Paige",
          order: "5545",
          location: "Suite 382, North Wills 60670-9001",
          price: "750",
          mobile: "9034342475",
          date: "08/15/2020",
          time: "9:08 AM"
        },
        {
          name: "Mr.Paige",
          order: "5545",
          location: "Suite 382, North Wills 60670-9001",
          price: "750",
          mobile: "9034342475",
          date: "08/15/2020",
          time: "9:08 AM"
        },
      ],
      page: "Page 1 of 10< >"
    }
  }
  render() {
    return (
      <div className="dashboard-body">
        <div className="container-fluid">
          <div className="row">
            <div className="col-12 col-md-5">
              <div className="dashboard-div">
                <div className="row">
                  <div className="col-1 col-md-auto">Tasks</div>
                  <div className="col-1 col-md-auto ml-auto">
                    <span className="dashboard-task-content">
                      Today
                    </span>
                  </div>
                  <div className="col-12 col-md-12 mt-1 ml-auto dashboard-bottom ">
                    <div className="row">
                      <div className="col-6 col-md-4">New Tasks (5)</div>
                      <div className="col-6 col-md-4">Ongoing (29)</div>
                      <div className="col-6 col-md-4">Completed (70)</div>
                    </div>
                  </div>
                </div>
              </div>
              {this.state.user.map((users) => (
                <div className="dashboard-content">
                  <div className="row dashboard-content-row">
                    <div className="col-md-11">
                      <div className="col-md-12 p-1">
                        <div className="row">
                          <div className="col-3 col-md-4 pr-2">
                            <b>{users.name}</b>
                          </div>
                          <div className="col-4  col-md-4 offset-4">
                            OrderID: {users.order}
                          </div>
                        </div>
                      </div>
                      <div className="col-md-12 p-1">
                        <div className="row">
                          <div className="col-6 col-md-8">
                            {users.location}
                          </div>
                          <div className="col-4 col-md-2 offset-1 mr-6" style={{ textAlign: "right" }}>
                            <b>$ {users.price}</b>
                          </div>
                        </div>
                      </div>
                      <div className="col-md-12 p-1">
                        <div className="row">
                          <div className="col-md-6">
                            M: +91 {users.mobile}
                          </div>
                        </div>
                      </div>
                      <div className="col-md-12">
                        <div className="row">
                          <div className="col-12 col-md-6 offset-6 mr-1 pl-6">
                            {users.date}  {users.time}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="col-md-1 hov">
                      <div className="row">
                        <div className="col-md-12 line">
                          <div className="col-md-12 assign">
                            <span className="material-icons">
                              add_circle_outline
                            </span>
                          </div>
                          <div className="col-md-12 assign1"><b>Assign</b>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                ))}
              <div className="row">
                <div className="col-12 col-md-12 p-4" style={{ textAlign: "right" }}>
                  <label for="cars">Item per Page</label>
                  <select id="page" name="pages">
                    <option value="volvo">10</option>
                    <option value="saab">1</option>
                    <option value="fiat">2</option>
                    <option value="audi">3</option>
                  </select> {this.state.page}
                </div>
              </div>
            </div>
            <div className="col-12 col-md-7 map">
              <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14013.070261001383!2d77.23846792360418!3d28.591748909989334!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390ce31b6c2a8cdd%3A0x348bba0ae3ba9328!2sNizamuddin%2C%20Humayun&#39;s%20Tomb%2C%20Nizamuddin%20West%2C%20New%20Delhi%2C%20Delhi!5e0!3m2!1sen!2sin!4v1623656100856!5m2!1sen!2sin"
                allowfullscreen="" loading="lazy">
              </iframe>
            </div>
          </div>

        </div>
      </div>
    )
  }
}
