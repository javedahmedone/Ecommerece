import React, { Component } from 'react'
import './Sidebar.scss';
import { Link } from "react-router-dom";

export default class Sidebar extends Component {
  constructor(props) {
    super(props);
    this.state = {
      clicked: false
    };
  }

  showSidebar = () => {
    this.setState({ clicked: !this.state.clicked });
  };

  render() {
    return (
      <div className="sidebar-layout">
        <div className={
          this.state.clicked ? "top-navigation" : "top-navigation-full"
        }>
          <nav className="navbar navbar-dark bg-light text-dark d-flex justify-content-between">
            <span
              className="material-icons menu-btn"
              onClick={this.showSidebar.bind(this)}>
              menu
            </span>
            <div>
              <div className="">
                <img alt="User" src="Icon awesome-user-alt.png" style={{ height: "27px", width: "27px" }} />
                <span style={{ padding: "20px" }}>Super Admin</span>
              </div>
            </div>
          </nav>
        </div>

        <div className={
          this.state.clicked
            ? "side-navigation bg-white rounded shadow "
            : "side-navigation-hidden "
        }>
          <div className="w-100 d-flex justify-content-around">
            <img
              src="relinns.png"
              alt="relinns-logo"
              className="logo-img  d-flex justify-content-between"
            />
          </div>
          <ul className="list-group justify-content-center">
            <li className="list-group-item border-0">
              <Link to="/dashboard" style={{ textDecoration: 'none', color: "#616161" }}>
                <img alt="Dashboard" src="Icon material-dashboard.svg" />
                <span style={{ padding: "10px" }}> Dashboard</span>
              </Link>
            </li>

            <li className="list-group-item border-0">
              <Link to="/user" style={{ textDecoration: 'none', color: "#616161" }}>
                <img alt="User" src="Icon metro-users.png" />
                <span style={{ padding: "10px" }}> Users</span>
              </Link>
            </li>



            <Link to="/content" style={{ textDecoration: 'none', color: "#616161" }}>
              <li className="list-group-item border-0 " style={{ textDecoration: "none" }}>
                <img alt="User" src="Icon material-content-copy.png" />
                <span style={{ padding: "10px" }}> Content</span>
              </li>
            </Link>


            <Link to="/analytics" style={{ textDecoration: 'none', color: "#616161" }}>
              <li className="list-group-item border-0 " style={{ textDecoration: "none" }}>
                <img alt="Analytics" src="Icon ionic-md-analytics.png" />
                <span style={{ padding: "10px" }}> Analytics</span>
              </li>
            </Link>

            <Link to="/settings" style={{ textDecoration: 'none', color: "#616161" }}>
              <li className="list-group-item border-0 " style={{ textDecoration: "none" }}>
                <img alt="settings" src="Icon ionic-md-settings.png" />
                <span style={{ padding: "10px" }}> Settings</span>
              </li>
            </Link>
                      
            <Link to="/support" style={{ textDecoration: 'none', color: "#616161" }}>
              <li className="list-group-item border-0 " style={{ textDecoration: "none" }}>
                <img alt="support" src="Icon material-call.png" />
                <span style={{ padding: "10px" }}> Support</span>
              </li>
            </Link>
          
            <li className="list-group-item border-0">
              <img alt="User" src="Icon material-chat.png" />
              <span style={{ padding: "10px" }}> Chat</span>
            </li>

            <li className="list-group-item border-0">
              <img alt="User" src="Icon material-email.png" />
              <span style={{ padding: "10px" }}> Emails</span>
            </li>
            
          </ul>
        </div>

        <div
          className={this.state.clicked ? "main-content" : "main-content-full"}
        >
          {this.props.children}
        </div>

        <div className={this.state.clicked ? "footer" : "footer-full"}>
          <nav className="navbar navbar-dark bg-light text-dark">
            <span className={"m-auto"}>
              All rights Reserved. AppsRhino 2017- 2020
            </span>
          </nav>
        </div>
      </div>
    )
  }
}
