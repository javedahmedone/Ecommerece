import { Route, Switch } from 'react-router-dom';
import Home from './components/home';
import Dashboard from './components/dashboard/dashboard';
import User from './components/user/User';
import Sidebar from './components/sidebar/Sidebar';
import Content from './components/content/Content';
import Analytics from './components/analytics/analytics';
import Settings from './components/settings/settings';
import Support from './components/support/support';
import BoonzeBlue from './components/boonzeBlue/boonzeBlue'
import { Component } from 'react';
class App extends Component {
  
  render() {
    return (
      <>
        <Switch>
          <Route exact path='/' component={() => <Home />} />
          <Route exact path='/boonze-blue' component={() => <BoonzeBlue />} />
          <Route exact path='/side' component={() => <Sidebar />} />
          <Sidebar>
          <Route exact path='/dashboard' component={() => <Dashboard />} />
          <Route exact path='/content' component={() => <Content />} />
          <Route exact path='/user' component={() => <User />} />
          <Route exact path='/analytics' component={() => <Analytics />} />
          <Route path="/analytics/:type">
            <Analytics />
          </Route>
          <Route exact path='/settings' component={() => <Settings />} />
          <Route path="/settings/:type">
            <Settings />
          </Route>
          <Route exact path='/support' component={() => <Support />} />
          <Route path="/support/:type">
            <Support />
          </Route>
          </Sidebar>
          
        </Switch>
      </>
    );
  }
}
export default App;
