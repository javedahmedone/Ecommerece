import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LayoutComponent } from './layout.component';

const routes: Routes = [
  // { path: 'dashboard', component:DashboardComponent }
   { path: '',
    component: LayoutComponent,
    children: [
      {
        path: 'dashboard',
        loadChildren: () =>
          import('../dashboard/dashboard.module').then(
            (m) => m.DashboardModule
          ),
      },
    ]
    }

    //   {
    //     path: 'users',
    //     loadChildren: () =>
    //       import('../users/users.module').then((m) => m.UsersModule),
    //   },
    //   {
    //     path: 'content',
    //     loadChildren: () =>
    //       import('../content/content.module').then((m) => m.ContentModule),
    //   },
    //   {
    //     path: 'settings',
    //     loadChildren: () =>
    //       import('../settings/settings.module').then((m) => m.SettingsModule),
    //   },
    //   {
    //     path: 'analyitcs',
    //     loadChildren: () =>
    //       import('../analytics/analytics.module').then(
    //         (m) => m.AnalyticsModule
    //       ),
    //   },
    //   {
    //     path: 'support',
    //     loadChildren: () =>
    //       import('../support/support.module').then((m) => m.SupportModule),
    //   },
    ]
  


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class LayoutRoutingModule {}
