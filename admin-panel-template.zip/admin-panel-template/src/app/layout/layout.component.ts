import { Component, OnInit, ɵɵtrustConstantResourceUrl } from '@angular/core';

@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.css']
})
export class LayoutComponent implements OnInit {

  isMenuOpen =  true;
  contentMargin = 200;

  onHover = false;

  constructor() { }

  ngOnInit(): void {
  }

  onToolbarMenuToggle(){
    this.isMenuOpen = !this.isMenuOpen
    if(!this.isMenuOpen) this.contentMargin = 50;
    else this.contentMargin = 200;
  }

}

