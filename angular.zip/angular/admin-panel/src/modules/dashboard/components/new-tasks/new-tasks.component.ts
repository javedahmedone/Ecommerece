import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-tasks',
  templateUrl: './new-tasks.component.html',
  styleUrls: ['./new-tasks.component.css']
})
export class NewTasksComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
