import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './dashboard.component';
import { MatIconModule } from '@angular/material/icon';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatTabsModule } from '@angular/material/tabs';
import { NewTasksComponent } from './components/new-tasks/new-tasks.component';
import { OngoingComponent } from './components/ongoing/ongoing.component';
import { CompletedComponent } from './components/completed/completed.component';


@NgModule({
  declarations: [
    DashboardComponent,
    NewTasksComponent,
    OngoingComponent,
    CompletedComponent
  ],
  imports: [
    CommonModule,
    DashboardRoutingModule,
    MatIconModule,
    MatPaginatorModule,
    MatTabsModule
  ]
})
export class DashboardModule { }
