import { Component, OnInit, ɵɵtrustConstantResourceUrl } from '@angular/core';

@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.css']
})
export class LayoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  setActive(elem : any){
    console.log(elem);
    const elements = document.querySelectorAll('.nav-item')
    console.log(elements)
    elements.forEach(element => {
      element.classList.remove('active')
    })
    elem.classList.add('active')
  }

}
