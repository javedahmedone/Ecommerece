import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-and-signup',
  templateUrl: './login-and-signup.component.html',
  styleUrls: ['./login-and-signup.component.css']
})
export class LoginAndSignupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
