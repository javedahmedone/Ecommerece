import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-catalogues',
  templateUrl: './catalogues.component.html',
  styleUrls: ['./catalogues.component.css']
})
export class CataloguesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
