import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ContentRoutingModule } from './content-routing.module';
import { ContentComponent } from './content.component';

import { MatIconModule } from '@angular/material/icon';
import { MatTabsModule } from '@angular/material/tabs';
import { CataloguesComponent } from './components/catalogues/catalogues.component';
import { LocationsComponent } from './components/locations/locations.component';
import { ProductCategoryComponent } from './components/product-category/product-category.component';
import { ProductsComponent } from './components/products/products.component';
import { SharedModule } from '../shared/shared.module';


@NgModule({
  declarations: [
    ContentComponent,
    CataloguesComponent,
    LocationsComponent,
    ProductCategoryComponent,
    ProductsComponent
  ],
  imports: [
    CommonModule,
    ContentRoutingModule,
    MatIconModule,
    MatTabsModule,
    SharedModule
  ]
})
export class ContentModule { }
