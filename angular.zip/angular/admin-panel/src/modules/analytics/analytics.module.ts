import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChartsModule } from 'ng2-charts';

import { AnalyticsRoutingModule } from './analytics-routing.module';
import { AnalyticsComponent } from './analytics.component';
import { MatIconModule } from '@angular/material/icon';
import { MatTabsModule } from '@angular/material/tabs';
import { DeliveriesComponent } from './components/deliveries/deliveries.component';
import { PaymentsComponent } from './components/payments/payments.component';
import { CustomComponent } from './components/custom/custom.component';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerModule } from '@angular/material/datepicker';




@NgModule({
  declarations: [
    AnalyticsComponent,
    DeliveriesComponent,
    PaymentsComponent,
    CustomComponent
  ],
  imports: [
    CommonModule,
    AnalyticsRoutingModule,
    MatIconModule,
    MatTabsModule,
    MatInputModule,
    MatDatepickerModule,
    ChartsModule
  ]
})
export class AnalyticsModule { }
