import { Component, OnInit } from '@angular/core';
import { ChartOptions, ChartType, ChartDataSets } from 'chart.js';
import { Color, Label, MultiDataSet } from 'ng2-charts';

@Component({
  selector: 'app-payments',
  templateUrl: './payments.component.html',
  styleUrls: ['./payments.component.css'],
})
export class PaymentsComponent implements OnInit {
  //bar chart properties
  public barChartOptions: ChartOptions = {
    scales: {
      xAxes: [
        {
          ticks: {
            display: false,
          },
          gridLines: {
            display: false,
          },
        },
      ],
      yAxes: [
        {
          ticks: {
            display: false,
          },
          gridLines: {
            display: false,
          },
        },
      ],
    },
    tooltips: {
      enabled: true,
    },
    responsive: true,
  };

  public barChartLabels: Label[] = [
    '2006',
    '2007',
    '2008',
    '2009',
    '2010',
    '2011',
    '2012',
  ];
  public barChartType: ChartType = 'bar';
  // public barChartColors1: Color[] = [
  //   {
  //     backgroundColor: '#55D8FE',
  //   },
  // ];

  // public barChartColors2: Color[] = [
  //   {
  //     backgroundColor: '#FF9A9E',
  //   },
  // ];

  // public barChartColors3: Color[] = [
  //   {
  //     backgroundColor: '#A18CD1',
  //   },
  // ];

  // public barChartColors4: Color[] = [
  //   {
  //     backgroundColor: '#ABECD6',
  //   },
  // ];

  public barChartLegend = false;
  public barChartPlugins = [];

  public barChartData: ChartDataSets[] = [
    { data: [65, 59, 80, 81, 56, 55, 40], label: 'Series A' },
  ];

  //Line chart properties

  lineChartData: ChartDataSets[] = [
    { data: [85, 72, 78, 75, 77, 75], label: 'Earnings' },
  ];

  lineChartLabels: Label[] = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
  ];

  lineChartOptions: ChartOptions = {
    legend: {
      display: true,
      align: 'start',
      position: 'top',
      fullWidth: true,
    },
    responsive: true,
  };

  lineChartColors: Color[] = [
    {
      borderColor: '#8F8BFF',
      backgroundColor: '#fff',
    },
  ];

  lineChartLegend = true;
  lineChartPlugins = [];
  lineChartType: ChartType = 'line';

  // DONat chart
  doughnutChartOptions: ChartOptions = {
    legend: {
      display: true,
      align: 'center',
      position: 'right',
      fullWidth: true,
    },
  };
  doughnutChartLabels: Label[] = [
    'Stores',
    'Delivery Person',
    'Super Admin',
    'Others',
  ];
  doughnutChartData: MultiDataSet = [[50, 25, 20, 5]];
  doughnutChartType: ChartType = 'doughnut';
  constructor() {}

  ngOnInit(): void {}
}
