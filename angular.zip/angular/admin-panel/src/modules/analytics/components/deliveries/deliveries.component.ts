import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deliveries',
  templateUrl: './deliveries.component.html',
  styleUrls: ['./deliveries.component.css'],
})
export class DeliveriesComponent implements OnInit {
  deliveries = [
    {
      orderId: '2070',
      customerName: 'Mellie Ernser',
      store: 'Mellie Ernser',
      rider: 'Candido Hauck',
      status: 'Pending',
    },
    {
      orderId: '2070',
      customerName: 'Mellie Ernser',
      store: 'Mellie Ernser',
      rider: 'Candido Hauck',
      status: 'Pending',
    },
    {
      orderId: '2070',
      customerName: 'Mellie Ernser',
      store: 'Mellie Ernser',
      rider: 'Candido Hauck',
      status: 'Pending',
    },
    {
      orderId: '2070',
      customerName: 'Mellie Ernser',
      store: 'Mellie Ernser',
      rider: 'Candido Hauck',
      status: 'Pending',
    },
    {
      orderId: '2070',
      customerName: 'Mellie Ernser',
      store: 'Mellie Ernser',
      rider: 'Candido Hauck',
      status: 'Pending',
    },
    {
      orderId: '2070',
      customerName: 'Mellie Ernser',
      store: 'Mellie Ernser',
      rider: 'Candido Hauck',
      status: 'Pending',
    },
    {
      orderId: '2070',
      customerName: 'Mellie Ernser',
      store: 'Mellie Ernser',
      rider: 'Candido Hauck',
      status: 'Pending',
    },
    {
      orderId: '2070',
      customerName: 'Mellie Ernser',
      store: 'Mellie Ernser',
      rider: 'Candido Hauck',
      status: 'Pending',
    },
    {
      orderId: '2070',
      customerName: 'Mellie Ernser',
      store: 'Mellie Ernser',
      rider: 'Candido Hauck',
      status: 'Pending',
    },
    {
      orderId: '2070',
      customerName: 'Mellie Ernser',
      store: 'Mellie Ernser',
      rider: 'Candido Hauck',
      status: 'Pending',
    },
    {
      orderId: '2070',
      customerName: 'Mellie Ernser',
      store: 'Mellie Ernser',
      rider: 'Candido Hauck',
      status: 'Pending',
    },
    {
      orderId: '2070',
      customerName: 'Mellie Ernser',
      store: 'Mellie Ernser',
      rider: 'Candido Hauck',
      status: 'Pending',
    },
    {
      orderId: '2070',
      customerName: 'Mellie Ernser',
      store: 'Mellie Ernser',
      rider: 'Candido Hauck',
      status: 'Pending',
    },
    {
      orderId: '2070',
      customerName: 'Mellie Ernser',
      store: 'Mellie Ernser',
      rider: 'Candido Hauck',
      status: 'Pending',
    },
    {
      orderId: '2070',
      customerName: 'Mellie Ernser',
      store: 'Mellie Ernser',
      rider: 'Candido Hauck',
      status: 'Pending',
    },
    {
      orderId: '2070',
      customerName: 'Mellie Ernser',
      store: 'Mellie Ernser',
      rider: 'Candido Hauck',
      status: 'Pending',
    },
  ];

  constructor() {}

  ngOnInit(): void {}
}
