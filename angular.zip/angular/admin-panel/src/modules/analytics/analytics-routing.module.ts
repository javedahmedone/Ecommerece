import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AnalyticsComponent } from './analytics.component';
import { CustomComponent } from './components/custom/custom.component';
import { DeliveriesComponent } from './components/deliveries/deliveries.component';
import { PaymentsComponent } from './components/payments/payments.component';

const routes: Routes = [
  { path: '', component: AnalyticsComponent, children: [
    {path: 'deliveries', component : DeliveriesComponent},
    {path: 'payments', component: PaymentsComponent},
    {path: 'cusotm', component: CustomComponent}
  ] }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AnalyticsRoutingModule { }
