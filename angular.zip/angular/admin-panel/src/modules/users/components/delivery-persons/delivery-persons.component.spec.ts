import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeliveryPersonsComponent } from './delivery-persons.component';

describe('DeliveryPersonsComponent', () => {
  let component: DeliveryPersonsComponent;
  let fixture: ComponentFixture<DeliveryPersonsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeliveryPersonsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeliveryPersonsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
