import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delivery-persons',
  templateUrl: './delivery-persons.component.html',
  styleUrls: ['./delivery-persons.component.css']
})
export class DeliveryPersonsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
