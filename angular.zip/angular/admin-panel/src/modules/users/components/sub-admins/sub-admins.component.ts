import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sub-admins',
  templateUrl: './sub-admins.component.html',
  styleUrls: ['./sub-admins.component.css']
})
export class SubAdminsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
