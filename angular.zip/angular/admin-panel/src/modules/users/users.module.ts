import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UsersRoutingModule } from './users-routing.module';
import { UsersComponent } from './users.component';
import { MatIconModule } from '@angular/material/icon';
import { MatTabsModule } from '@angular/material/tabs';
import { CustomersComponent } from './components/customers/customers.component';
import { StoresComponent } from './components/stores/stores.component';
import { DeliveryPersonsComponent } from './components/delivery-persons/delivery-persons.component';
import { SubAdminsComponent } from './components/sub-admins/sub-admins.component';


@NgModule({
  declarations: [
    UsersComponent,
    CustomersComponent,
    StoresComponent,
    DeliveryPersonsComponent,
    SubAdminsComponent
  ],
  imports: [
    CommonModule,
    UsersRoutingModule,
    MatIconModule,
    MatTabsModule,
  ]
})
export class UsersModule { }
