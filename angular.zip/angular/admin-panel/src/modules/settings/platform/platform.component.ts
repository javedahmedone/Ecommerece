import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-platform',
  templateUrl: './platform.component.html',
  styleUrls: ['./platform.component.css']
})
export class PlatformComponent implements OnInit {

  toggle = false;

  notifications = [
    { message: "Task Created Successfully by Customer", toggle: true },
    { message: "Payment is pending for the order", toggle: false },
    { message: "Task Created Successfully by Customer", toggle: true },
    { message: "Payment is pending for the order", toggle: false },
    { message: "Task Created Successfully by Customer", toggle: true },
    { message: "Payment is pending for the order", toggle: false },
    { message: "Task Created Successfully by Customer", toggle: true },
    { message: "Payment is pending for the order", toggle: false },
    { message: "Task Created Successfully by Customer", toggle: true },
    { message: "Payment is pending for the order", toggle: false },
    { message: "Task Created Successfully by Customer", toggle: true },
    { message: "Payment is pending for the order", toggle: false },
    { message: "Task Created Successfully by Customer", toggle: true },
    { message: "Payment is pending for the order", toggle: false },
    { message: "Task Created Successfully by Customer", toggle: true },
    { message: "Payment is pending for the order", toggle: false },
    { message: "Task Created Successfully by Customer", toggle: true },
    { message: "Payment is pending for the order", toggle: false },
    { message: "Task Created Successfully by Customer", toggle: true },
    { message: "Payment is pending for the order", toggle: false },
  ]


  areas = [
    {area : "Kerlukeburgh"},
    {area : "Chelseaview"},
    {area : "West Caylaton"},
    {area : "New Ladariusshire"},
    {area : "Ziemannfort"},
    {area : "New Susieborough"},
    {area : "Port Gayletown"},
    {area : "West Timmy"},
    {area : "Gloverfurt"},
    {area : "Melanyfurt"},
    {area : "Bartolettiport"},
    {area : "West Dawn"},
    {area : "West Lamar"},
    {area : "Danetown"},
    {area : "Armstrongfurt"},
  ]

  constructor() { }

  ngOnInit(): void {
  }

}
