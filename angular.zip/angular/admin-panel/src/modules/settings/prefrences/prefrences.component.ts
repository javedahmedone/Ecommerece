import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prefrences',
  templateUrl: './prefrences.component.html',
  styleUrls: ['./prefrences.component.css']
})
export class PrefrencesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
