import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SettingsRoutingModule } from './settings-routing.module';
import { SettingsComponent } from './settings.component';
import { PlatformComponent } from './platform/platform.component';
import { IntegrationsComponent } from './integrations/integrations.component';
import { PaymentComponent } from './payment/payment.component';
import { PrefrencesComponent } from './prefrences/prefrences.component';
import { LegalComponent } from './legal/legal.component';
import { MatTabsModule } from '@angular/material/tabs'
import { MatIconModule } from '@angular/material/icon';


@NgModule({
  declarations: [
    SettingsComponent,
    PlatformComponent,
    IntegrationsComponent,
    PaymentComponent,
    PrefrencesComponent,
    LegalComponent
  ],
  imports: [
    CommonModule,
    SettingsRoutingModule,
    MatTabsModule,
    MatIconModule
  ]
})
export class SettingsModule { }
