import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedRoutingModule } from './shared-routing.module';
import { SharedComponent } from './shared.component';
import { TableComponent } from './table/table.component';
import { MatTableModule } from '@angular/material/table';
import { MatCheckboxModule } from '@angular/material/checkbox'


@NgModule({
  declarations: [
    SharedComponent,
    TableComponent
  ],
  imports: [
    CommonModule,
    SharedRoutingModule,
    MatTableModule,
    MatCheckboxModule
  ],
  exports: [
    TableComponent
  ]
})
export class SharedModule { }
