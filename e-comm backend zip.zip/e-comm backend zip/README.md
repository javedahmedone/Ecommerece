# Node.js TypeScript Template

> ## Steps to follow.

> 1. Download the source code (do not clone, just download)
> 2. Change folder name with your service name
> 2. Run `git init`
> 3. Run `npm init --yes`
> 4. Run `npm i -g yarn` or `sudo npm i -g yarn`
> 5. Run `bash dependencies.sh`
